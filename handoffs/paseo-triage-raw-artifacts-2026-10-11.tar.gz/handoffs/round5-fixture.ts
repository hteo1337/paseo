import { execFileSync } from 'node:child_process';
import { mkdtempSync, mkdirSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { client, logger } from './round4-helpers.js';
import { AgentManager } from '../packages/server/src/server/agent/agent-manager.js';
import { AgentStorage } from '../packages/server/src/server/agent/agent-storage.js';
import { createWorktree } from '../packages/server/src/utils/worktree.js';
export async function fixture() {
  const base=mkdtempSync(resolve('handoffs/round4-fixture-'));
  const repo=join(base,'repo');mkdirSync(repo);
  const git=(args:string[])=>execFileSync('git',args,{cwd:repo,stdio:'pipe'});
  git(['init','-b','main']);
  git(['-c','user.name=Probe','-c','user.email=probe@example.test','-c','commit.gpgsign=false','commit','--allow-empty','-m','fixture']);
  const home=join(base,'home');
  const tree=await createWorktree({cwd:repo,worktreeSlug:'probe',source:{kind:'branch-off',baseBranch:'main',branchName:'probe'},runSetup:false,paseoHome:home});
  const cwd=tree.worktreePath;
  const {c,sessions}=client();const storage=new AgentStorage(join(home,'agents'),logger);const m=new AgentManager({clients:{codex:c},registry:storage,logger});
  let archived=false;
  const deps:any={paseoHome:home,agentManager:m,agentStorage:storage,
    listActiveWorkspaces:async()=>archived?[]:[{workspaceId:'w',cwd,kind:'worktree',isPaseoOwnedWorktree:true,worktreeRoot:cwd,mainRepoRoot:repo}],
    archiveWorkspaceRecord:async()=>{archived=true},markWorkspaceArchiving:()=>{},clearWorkspaceArchiving:()=>{},
    emitWorkspaceUpdatesForWorkspaceIds:async()=>{},killTerminalsForWorkspace:async()=>{},
    workspaceGitService:{getSnapshot:async()=>({})},github:{invalidate:()=>{}},sessionLogger:logger};
  return {base,cwd,home,c,sessions,m,deps};
}

