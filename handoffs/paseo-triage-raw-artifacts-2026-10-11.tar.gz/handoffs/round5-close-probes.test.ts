import { test, expect } from 'vitest';
import { existsSync, rmSync } from 'node:fs';
import { ACPAgentSession } from '../packages/server/src/server/agent/providers/acp-agent.js';
import { terminateWithTreeKill, type TreeKillTarget } from '../packages/server/src/utils/tree-kill.js';
import { archiveByScope } from '../packages/server/src/server/workspace-archive-service.js';
import { fixture } from './round5-fixture.js';
import { logger } from './round4-helpers.js';

test.each(['terminated','kill-timeout'] as const)('ACP close termination result control: %s',async(mode)=>{
  const f=await fixture();let child:TreeKillTarget|undefined;
  const acp=new ACPAgentSession({provider:'claude-acp',cwd:f.cwd},{provider:'claude-acp',logger,
    defaultCommand:['unused'],defaultModes:[],capabilities:{supportsStreaming:true,supportsSessionPersistence:true},
    terminateProcess:async(target,options)=>{
      child=target;
      if(mode==='kill-timeout')return 'kill-timeout';
      return terminateWithTreeKill(target,options);
    }});
  try{
    await acp.createTerminal({sessionId:'probe',command:process.execPath,args:['-e','setInterval(()=>{},1000)'],cwd:f.cwd});
    const a=await f.m.createAgent({provider:'codex',cwd:f.cwd},undefined,{workspaceId:'w'});
    f.sessions[0].close=()=>acp.close();
    const result=await archiveByScope(f.deps,{scope:{kind:'workspace',workspaceId:'w'},requestId:'close-probe',
      abortIf:()=>[],holdNewRuns:()=>f.m.holdNewRunsForArchive('w',f.cwd)});
    expect(child?.pid).toBeGreaterThan(0);expect(result.removedDirectory).toBe(true);
    expect(existsSync(f.cwd)).toBe(false);expect(f.m.getAgent(a.id)).toBeNull();
    if(mode==='kill-timeout'){
      expect(child?.exitCode).toBeNull();expect(child?.signalCode).toBeNull();
      expect(()=>process.kill(child!.pid!,0)).not.toThrow();
    }else expect(child?.exitCode!==null||child?.signalCode!==null).toBe(true);
  }finally{
    await acp.close();
    if(child)await terminateWithTreeKill(child,{gracefulTimeoutMs:1000,forceTimeoutMs:1000});
    rmSync(f.base,{recursive:true,force:true});
  }
});
