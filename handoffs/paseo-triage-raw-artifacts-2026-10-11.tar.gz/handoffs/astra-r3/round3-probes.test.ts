import { test, expect, vi } from "vitest";
import pino from "pino";
import { mkdtempSync, mkdirSync, symlinkSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { AgentManager } from "../packages/server/src/server/agent/agent-manager.js";
import { archiveIfSafe } from "../packages/server/src/server/auto-archive-on-merge/archive-if-safe.js";
import { setupAutoArchiveOnMerge } from "../packages/server/src/server/auto-archive-on-merge/index.js";
import { archiveByScope } from "../packages/server/src/server/workspace-archive-service.js";
const logger = pino({ level: "silent" });
const tick = () => new Promise<void>((r) => setImmediate(r));
const gate = () => {
  let release!: () => void;
  const promise = new Promise<void>((r) => (release = r));
  return { promise, release };
};
function client() {
  const sessions: any[] = [];
  const c: any = {
    provider: "codex",
    capabilities: {
      supportsStreaming: false,
      supportsSessionPersistence: false,
      supportsSessionListing: true,
    },
    isAvailable: async () => true,
    fetchCatalog: async () => ({ models: [], modes: [] }),
    createSession: async (config: any) => {
      const subscribers = new Set<any>();
      const s: any = {
        provider: "codex",
        id: crypto.randomUUID(),
        capabilities: c.capabilities,
        subscribe: (cb: any) => {
          subscribers.add(cb);
          return () => subscribers.delete(cb);
        },
        push: (event: any) => {
          for (const cb of subscribers) cb({ provider: "codex", ...event });
        },
        describePersistence: () => ({ provider: "codex", sessionId: s.id }),
        getRuntimeInfo: async () => ({
          provider: "codex",
          sessionId: s.id,
          model: null,
          modeId: null,
        }),
        getPendingPermissions: () => [],
        getAvailableModes: async () => [],
        getCurrentMode: async () => null,
        close: async () => {},
        interrupt: async () => {},
        streamHistory: async function* () {},
        startTurn: async () => ({ turnId: "foreground" }),
      };
      sessions.push(s);
      return s;
    },
  };
  c.resumeSession = async (_: any, config: any) => c.createSession(config);
  return { c, sessions };
}
function snapshot(merged = true): any {
  return {
    cwd: "/review/tree",
    git: { isDirty: false, aheadOfOrigin: 0 },
    forge: {
      pullRequest: {
        url: "https://example.test/pr/1",
        state: merged ? "merged" : "open",
        isMerged: merged,
      },
    },
  };
}
function journey(archive: any) {
  let emitSnapshot: any, emitAgent: any;
  const opts: any = {
    logger,
    daemonConfigStore: { get: () => ({ autoArchiveAfterMerge: true }) },
    agentManager: {
      subscribe: (cb: any) => {
        emitAgent = cb;
        return () => {};
      },
    },
    workspaceGitService: {
      onSnapshotUpdated: (cb: any) => {
        emitSnapshot = cb;
        return { unsubscribe() {} };
      },
      getSnapshot: vi.fn(async () => snapshot()),
    },
    listActiveWorkspaces: async () => [{ workspaceId: "w", cwd: "/review/tree" }],
  };
  const subscription = setupAutoArchiveOnMerge(opts, {
    archiveIfSafe: archive,
    resolvePath: resolve,
  });
  emitSnapshot(snapshot(false));
  emitSnapshot(snapshot());
  return { opts, subscription, emitAgent };
}
test("P1: autonomous turn enters while archive hold is active", async () => {
  const { c, sessions } = client();
  const m = new AgentManager({ clients: { codex: c }, logger });
  const a = await m.createAgent({ provider: "codex", cwd: process.cwd() }, undefined, {
    workspaceId: "w",
  });
  const release = m.holdNewRunsForArchive("w", process.cwd());
  expect(() => m.streamAgent(a.id, "control")).toThrow("being archived");
  expect(m.hasInFlightRun(a.id)).toBe(false);
  sessions[0].push({ type: "turn_started", turnId: "autonomous" });
  await tick();
  expect(m.getAgent(a.id)?.lifecycle).toBe("running");
  expect(m.hasInFlightRun(a.id)).toBe(true);
  release();
});
test.each(["create", "resume"])(
  "P1: %s registration and autonomous replay bypass hold",
  async (mode) => {
    const { c, sessions } = client();
    const m = new AgentManager({ clients: { codex: c }, logger });
    const original = c.createSession;
    c.createSession = async (config: any) => {
      const s = await original(config);
      const sub = s.subscribe;
      s.subscribe = (cb: any) => {
        const off = sub(cb);
        cb({ provider: "codex", type: "turn_started", turnId: "replayed" });
        return off;
      };
      return s;
    };
    const release = m.holdNewRunsForArchive("w", process.cwd());
    const a =
      mode === "create"
        ? await m.createAgent({ provider: "codex", cwd: process.cwd() }, undefined, {
            workspaceId: "w",
          })
        : await m.resumeAgentFromPersistence(
            { provider: "codex", sessionId: "saved" },
            { cwd: process.cwd() },
            undefined,
            { workspaceId: "w" },
          );
    await tick();
    expect(sessions.length).toBe(1);
    expect(m.hasInFlightRun(a.id)).toBe(true);
    release();
  },
);
test("P3: unsubscribe during real archiveIfSafe ownership await still archives", async () => {
  const held = gate();
  let entered = false;
  let archives = 0;
  const j = journey(async (input: any) =>
    archiveIfSafe({
      ...input,
      options: {
        ...input.options,
        paseoHome: "/review",
        getAutoArchivedChangeRequestUrl: async () => null,
        agentManager: { listAgents: () => [], hasInFlightRun: () => false },
      },
      deps: {
        isPaseoOwnedWorktreeCwd: async () => {
          entered = true;
          await held.promise;
          return { allowed: true, worktreePath: "/review/tree" };
        },
        archiveByScope: async () => {
          archives++;
          return { archivedAgentIds: [], archivedWorkspaceIds: ["w"], removedDirectory: true };
        },
        killTerminalsForWorkspace: async () => {},
      },
    }),
  );
  await vi.waitFor(() => expect(entered).toBe(true));
  expect(archives).toBe(0);
  j.subscription.unsubscribe();
  held.release();
  await tick();
  await tick();
  expect(archives).toBe(1);
});
test.each(["idle", "error", "closed"])(
  "claim2: %s event still retries after exhaustion",
  async (lifecycle) => {
    vi.useFakeTimers();
    try {
      let busy = true;
      let archives = 0;
      let calls = 0;
      const j = journey(async () => {
        calls++;
        if (busy) return "deferred";
        archives++;
        return "archived";
      });
      await vi.advanceTimersByTimeAsync(155000);
      expect(calls).toBe(6);
      expect(archives).toBe(0);
      busy = false;
      j.emitAgent({ type: "agent_state", agent: { lifecycle } });
      await vi.advanceTimersByTimeAsync(1);
      expect(archives).toBe(1);
      j.subscription.unsubscribe();
    } finally {
      vi.useRealTimers();
    }
  },
);
test("P2: exhausted retries plus failed stop-event snapshot strand deferral", async () => {
  vi.useFakeTimers();
  try {
    let busy = true;
    let archives = 0;
    let calls = 0;
    const j = journey(async () => {
      calls++;
      if (busy) return "deferred";
      archives++;
      return "archived";
    });
    await vi.advanceTimersByTimeAsync(155000);
    expect(calls).toBe(6);
    busy = false;
    j.opts.workspaceGitService.getSnapshot.mockRejectedValueOnce(new Error("transient"));
    j.emitAgent({ type: "agent_state", agent: { lifecycle: "error" } });
    await vi.advanceTimersByTimeAsync(1);
    await vi.advanceTimersByTimeAsync(3600000);
    expect(archives).toBe(0);
    expect(vi.getTimerCount()).toBe(0);
    j.emitAgent({ type: "agent_state", agent: { lifecycle: "idle" } });
    await vi.advanceTimersByTimeAsync(1);
    expect(archives).toBe(1);
    j.subscription.unsubscribe();
  } finally {
    vi.useRealTimers();
  }
});
test("claim4: path aliases match and sibling prefix stays independent; holds release independently", async () => {
  const root = mkdtempSync(join(tmpdir(), "round3-"));
  try {
    mkdirSync(join(root, "tree"));
    mkdirSync(join(root, "tree-sibling"));
    symlinkSync(join(root, "tree"), join(root, "alias"));
    const { c } = client();
    const m = new AgentManager({ clients: { codex: c }, logger });
    const alias = await m.createAgent({ provider: "codex", cwd: join(root, "alias") }, undefined, {
      workspaceId: "other",
    });
    const sibling = await m.createAgent(
      { provider: "codex", cwd: join(root, "tree-sibling") },
      undefined,
      { workspaceId: "sibling" },
    );
    const r1 = m.holdNewRunsForArchive("w", join(root, "tree"));
    const r2 = m.holdNewRunsForArchive("w", join(root, "tree"));
    expect(() => m.streamAgent(alias.id, "x")).toThrow("being archived");
    expect(() => m.streamAgent(sibling.id, "x")).not.toThrow();
    r1();
    expect(() => m.streamAgent(alias.id, "x")).toThrow("being archived");
    r2();
    expect(() => m.streamAgent(alias.id, "x")).not.toThrow();
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});
function archiveDeps(overrides: any = {}): any {
  return {
    listActiveWorkspaces: async () => [{ workspaceId: "w", cwd: "/review/tree", kind: "local" }],
    agentManager: { listAgents: () => [], getAgent: () => null },
    agentStorage: { listByWorkspace: async () => [] },
    markWorkspaceArchiving: () => {},
    clearWorkspaceArchiving: () => {},
    emitWorkspaceUpdatesForWorkspaceIds: async () => {},
    archiveWorkspaceRecord: async () => {},
    killTerminalsForWorkspace: async () => {},
    sessionLogger: logger,
    ...overrides,
  };
}
test.each(["stop", "mark", "emit", "record", "clear", "finalEmit"])(
  "claim4: release under %s exception",
  async (stage) => {
    let holds = 0;
    let releases = 0;
    let emits = 0;
    const boom = () => {
      throw Error("injected");
    };
    const deps = archiveDeps({
      stopWorkspaceSetup: async () => {
        if (stage === "stop") boom();
      },
      markWorkspaceArchiving: () => {
        if (stage === "mark") boom();
      },
      clearWorkspaceArchiving: () => {
        if (stage === "clear") boom();
      },
      emitWorkspaceUpdatesForWorkspaceIds: async () => {
        emits++;
        if (stage === "emit" || (stage === "finalEmit" && emits === 2)) boom();
      },
      archiveWorkspaceRecord: async () => {
        if (stage === "record") boom();
      },
    });
    await archiveByScope(deps, {
      scope: { kind: "workspace", workspaceId: "w" },
      requestId: "probe",
      abortIf: () => [],
      holdNewRuns: () => {
        holds++;
        return () => {
          releases++;
        };
      },
    }).catch(() => {});
    expect(holds).toBe(1);
    expect(releases).toBe(1);
  },
);
test("P1: real archive reaches record teardown with a cwd-only autonomous run", async () => {
  const { c, sessions } = client();
  const m = new AgentManager({ clients: { codex: c }, logger });
  const cwd = process.cwd();
  const a = await m.createAgent({ provider: "codex", cwd }, undefined, { workspaceId: "other" });
  let emitCount = 0;
  let busyAtRecord = false;
  let admissionBlocked = false;
  const deps = archiveDeps({
    agentManager: m,
    listActiveWorkspaces: async () => [{ workspaceId: "w", cwd, kind: "local" }],
    emitWorkspaceUpdatesForWorkspaceIds: async () => {
      if (++emitCount === 1) {
        try {
          m.streamAgent(a.id, "control");
        } catch {
          admissionBlocked = true;
        }
        sessions[0].push({ type: "turn_started", turnId: "after-hold" });
        await tick();
      }
    },
    archiveWorkspaceRecord: async () => {
      busyAtRecord = m.hasInFlightRun(a.id);
    },
  });
  const result = await archiveByScope(deps, {
    scope: { kind: "workspace", workspaceId: "w" },
    requestId: "probe",
    abortIf: () => (m.hasInFlightRun(a.id) ? [a.id] : []),
    holdNewRuns: () => m.holdNewRunsForArchive("w", cwd),
  });
  expect(admissionBlocked).toBe(true);
  expect(busyAtRecord).toBe(true);
  expect(result.archivedWorkspaceIds).toEqual(["w"]);
});
test("claim2: stop event overlapping a deferred flight causes another flight", async () => {
  const held = gate();
  let calls = 0;
  const j = journey(async () => {
    calls++;
    if (calls === 1) {
      await held.promise;
      return "deferred";
    }
    return "archived";
  });
  await vi.waitFor(() => expect(calls).toBe(1));
  j.emitAgent({ type: "agent_state", agent: { lifecycle: "closed" } });
  await tick();
  held.release();
  await vi.waitFor(() => expect(calls).toBe(2));
  j.subscription.unsubscribe();
});
test("P1: dot-dot-prefixed descendant bypasses path hold", async () => {
  const root = mkdtempSync(join(tmpdir(), "round3-dotdot-"));
  try {
    mkdirSync(join(root, "..cache"));
    mkdirSync(join(root, "ordinary"));
    const { c } = client();
    const m = new AgentManager({ clients: { codex: c }, logger });
    const a = await m.createAgent({ provider: "codex", cwd: join(root, "..cache") }, undefined, {
      workspaceId: "other",
    });
    const b = await m.createAgent({ provider: "codex", cwd: join(root, "ordinary") }, undefined, {
      workspaceId: "other",
    });
    const release = m.holdNewRunsForArchive("w", root);
    expect(() => m.streamAgent(b.id, "control")).toThrow("being archived");
    expect(() => m.streamAgent(a.id, "probe")).not.toThrow();
    expect(m.hasInFlightRun(a.id)).toBe(true);
    release();
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});
test("claim4: existing on-disk case alias remains held", async () => {
  const root = mkdtempSync(join(tmpdir(), "round3-case-"));
  try {
    mkdirSync(join(root, "MixedCase"));
    const { statSync } = await import("node:fs");
    expect(statSync(join(root, "mixedcase")).ino).toBe(statSync(join(root, "MixedCase")).ino);
    const { c } = client();
    const m = new AgentManager({ clients: { codex: c }, logger });
    const a = await m.createAgent({ provider: "codex", cwd: join(root, "mixedcase") }, undefined, {
      workspaceId: "other",
    });
    const release = m.holdNewRunsForArchive("w", join(root, "MixedCase"));
    expect(() => m.streamAgent(a.id, "x")).toThrow("being archived");
    release();
    expect(() => m.streamAgent(a.id, "x")).not.toThrow();
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});
