// Round-6 adversarial probes for patch 0020. Real AgentManager, AgentStorage,
// archiveIfSafe, archiveByScope and git worktree; only providers are fakes.
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import pino from "pino";
import { afterEach, expect, test, vi } from "vitest";

import { AgentManager } from "../packages/server/src/server/agent/agent-manager.js";
import { AgentStorage } from "../packages/server/src/server/agent/agent-storage.js";
import type {
  AgentClient,
  AgentSession,
  AgentSessionConfig,
  AgentStreamEvent,
} from "../packages/server/src/server/agent/agent-sdk-types.js";
import {
  archiveIfSafe,
  type AutoArchiveArchiveOptions,
} from "../packages/server/src/server/auto-archive-on-merge/archive-if-safe.js";
import { archiveByScope } from "../packages/server/src/server/workspace-archive-service.js";
import type { WorkspaceGitRuntimeSnapshot } from "../packages/server/src/server/workspace-git-service.js";
import { createWorktree } from "../packages/server/src/utils/worktree.js";
import { isPaseoOwnedWorktreeCwd } from "../packages/server/src/utils/worktree.js";

const logger = pino({ level: "silent" });
const cleanup: string[] = [];
afterEach(() => {
  for (const p of cleanup.splice(0)) rmSync(p, { recursive: true, force: true });
});

const CAPS = {
  supportsStreaming: false,
  supportsSessionPersistence: false,
  supportsSessionListing: false,
  supportsDynamicModes: false,
  supportsMcpServers: false,
  supportsReasoningStream: false,
  supportsToolInvocations: false,
} as const;

class ProbeSession {
  readonly provider = "codex" as const;
  readonly capabilities = CAPS;
  readonly id = `s-${Math.random().toString(36).slice(2)}`;
  subs = new Set<(e: AgentStreamEvent) => void>();
  onClose: () => Promise<void> = async () => {};
  closed = false;
  constructor(readonly config: AgentSessionConfig) {}
  async run() {
    return { sessionId: this.id, finalText: "", timeline: [] };
  }
  async startTurn() {
    return { turnId: "t" };
  }
  subscribe(cb: (e: AgentStreamEvent) => void) {
    this.subs.add(cb);
    return () => this.subs.delete(cb);
  }
  push(e: AgentStreamEvent) {
    for (const cb of this.subs) cb(e);
  }
  async *streamHistory(): AsyncGenerator<AgentStreamEvent> {}
  async getRuntimeInfo() {
    return { provider: this.provider, sessionId: this.id, model: null, modeId: null };
  }
  async getAvailableModes() {
    return [];
  }
  async getCurrentMode() {
    return null;
  }
  async setMode() {}
  getPendingPermissions() {
    return [];
  }
  async respondToPermission() {}
  describePersistence() {
    return { provider: this.provider, sessionId: this.id };
  }
  async interrupt() {}
  async close() {
    await this.onClose();
    this.closed = true;
  }
}

class ProbeClient {
  readonly provider = "codex" as const;
  readonly capabilities = CAPS;
  sessions: ProbeSession[] = [];
  gate: Promise<void> | null = null;
  gateStarted: (() => void) | null = null;
  async isAvailable() {
    return true;
  }
  async fetchCatalog() {
    return { models: [{ provider: "codex", id: "m", label: "m", isDefault: true }], modes: [] };
  }
  async createSession(config: AgentSessionConfig) {
    const s = new ProbeSession(config);
    this.sessions.push(s);
    if (this.gate) {
      this.gateStarted?.();
      await this.gate;
    }
    return s as unknown as AgentSession;
  }
  async resumeSession(_h: unknown, config?: Partial<AgentSessionConfig>) {
    return this.createSession({ provider: "codex", cwd: config?.cwd ?? "/" } as AgentSessionConfig);
  }
}

async function setup(slug: string) {
  const tempDir = mkdtempSync(path.join(tmpdir(), "p0020-r6-"));
  cleanup.push(tempDir);
  const repoDir = path.join(tempDir, "repo");
  mkdirSync(repoDir);
  const git = (...a: string[]) => execFileSync("git", a, { cwd: repoDir, stdio: "pipe" });
  git("init", "-b", "main");
  git("config", "user.email", "t@t");
  git("config", "user.name", "t");
  git("-c", "commit.gpgsign=false", "commit", "--allow-empty", "-m", "i");
  const paseoHome = path.join(tempDir, ".paseo");
  const wt = await createWorktree({
    cwd: repoDir,
    worktreeSlug: slug,
    source: { kind: "branch-off", baseBranch: "main", branchName: slug },
    runSetup: false,
    paseoHome,
  });
  const root = wt.worktreePath;
  writeFileSync(path.join(root, "work.txt"), "uncommitted-but-ignored?");
  const client = new ProbeClient();
  const storage = new AgentStorage(path.join(tempDir, "agents"), logger);
  const manager = new AgentManager({
    clients: { codex: client as unknown as AgentClient },
    registry: storage,
    logger,
  });
  const workspaceId = `ws-${slug}`;
  const archived = new Set<string>();
  const options = {
    paseoHome,
    daemonConfigStore: { get: () => ({ autoArchiveAfterMerge: true }) },
    workspaceGitService: { getSnapshot: async () => null },
    github: { invalidate: () => {} },
    agentManager: manager,
    agentStorage: storage,
    terminalManager: {},
    findWorkspaceIdForCwd: async () => workspaceId,
    listActiveWorkspaces: async () =>
      archived.has(workspaceId) ? [] : [{ workspaceId, cwd: root, kind: "worktree" }],
    getAutoArchivedChangeRequestUrl: async () => null,
    archiveWorkspaceRecord: async (id: string) => void archived.add(id),
    markWorkspaceArchiving: () => {},
    clearWorkspaceArchiving: () => {},
    emitWorkspaceUpdatesForWorkspaceIds: async () => {},
  } as unknown as AutoArchiveArchiveOptions;
  const snapshot = {
    cwd: root,
    git: { isGit: true, isDirty: false, aheadOfOrigin: 0 },
    forge: { pullRequest: { url: "https://x/pull/1", isMerged: true, state: "merged" } },
  } as unknown as WorkspaceGitRuntimeSnapshot;
  const run = () =>
    archiveIfSafe({
      workspaceId,
      snapshot,
      options,
      log: logger,
      deps: { archiveByScope, isPaseoOwnedWorktreeCwd, killTerminalsForWorkspace: async () => {} },
    });
  const create = (cwd = root, extra: Partial<AgentSessionConfig> = {}, ws = workspaceId) =>
    manager.createAgent({ provider: "codex", cwd, ...extra } as AgentSessionConfig, undefined, {
      workspaceId: ws,
    });
  return { root, client, storage, manager, workspaceId, archived, run, create };
}

const turnStarted = (turnId: string) =>
  ({ type: "turn_started", provider: "codex", turnId }) as AgentStreamEvent;

test("A1 provider-originated turn after the last busy check is killed by teardown", async () => {
  const h = await setup("a1");
  const agent = await h.create();
  const session = h.client.sessions[0];
  let busyAtClose: boolean | null = null;
  session.onClose = async () => {
    busyAtClose = h.manager.hasInFlightRun(agent.id);
  };
  const applySnapshot = h.storage.applySnapshot.bind(h.storage);
  let armed = false;
  vi.spyOn(h.storage, "applySnapshot").mockImplementation(async (...args) => {
    if (armed) {
      armed = false;
      session.push(turnStarted("autonomous"));
    }
    return applySnapshot(...args);
  });
  armed = true;
  const outcome = await h.run();
  console.log("A1", { outcome, busyAtClose, archived: [...h.archived] });
  expect(outcome).toBe("archived");
  expect(busyAtClose).toBe(true);
});

test("A1 control: same provider turn before archiveIfSafe defers", async () => {
  const h = await setup("a1c");
  const agent = await h.create();
  h.client.sessions[0].push(turnStarted("autonomous"));
  const outcome = await h.run();
  console.log("A1c", { outcome, busy: h.manager.hasInFlightRun(agent.id) });
  expect(outcome).toBe("deferred");
  expect(h.client.sessions[0].closed).toBe(false);
});

test.each([true, false])("A2 working agent internal=%s", async (internal) => {
  const h = await setup(`a2-${internal}`);
  const agent = await h.create(h.root, { internal });
  h.client.sessions[0].push(turnStarted("working"));
  await new Promise((r) => setTimeout(r, 20));
  const busy = h.manager.hasInFlightRun(agent.id);
  const outcome = await h.run();
  const after = h.manager.getAgent(agent.id);
  console.log("A2", { internal, busy, outcome, archived: [...h.archived], lifecycle: after?.lifecycle, closed: h.client.sessions[0].closed });
  expect(busy).toBe(true);
  expect(outcome).toBe(internal ? "archived" : "deferred");
});

test("A3 create in flight across the whole archive registers into the archived workspace", async () => {
  const h = await setup("a3");
  let release!: () => void;
  let started!: () => void;
  const startedP = new Promise<void>((r) => (started = r));
  h.client.gate = new Promise<void>((r) => (release = r));
  h.client.gateStarted = started;
  const creation = h.create();
  await startedP;
  const outcome = await h.run();
  release();
  const agent = await creation;
  console.log("A3", { outcome, archived: [...h.archived], agentWs: agent.workspaceId, lifecycle: agent.lifecycle });
  expect(outcome).toBe("archived");
  expect(h.archived.has(agent.workspaceId ?? "")).toBe(true);
  expect(() => h.manager.streamAgent(agent.id, "go")).not.toThrow();
});

test("B auto-archive leaves the directory and its contents intact", async () => {
  const h = await setup("b");
  await h.create();
  const before = readdirSync(h.root).sort();
  const outcome = await h.run();
  const after = existsSync(h.root) ? readdirSync(h.root).sort() : null;
  console.log("B", { outcome, before, after });
  expect(outcome).toBe("archived");
  expect(after).toEqual(before);
});

test("C hold persists while a target close never settles", async () => {
  const h = await setup("c");
  await h.create();
  h.client.sessions[0].onClose = () => new Promise(() => {});
  let settled = false;
  void h.run().then(() => (settled = true));
  await new Promise((r) => setTimeout(r, 1500));
  const createErr = await h.create().then(
    () => null,
    (e: Error) => e.message,
  );
  console.log("C", { settled, createErr, active: h.archived.size === 0 });
  expect(settled).toBe(false);
  expect(createErr).toContain("being archived");
});

test("C control: hold released after every settled exit (defer, throw)", async () => {
  const h = await setup("cc");
  const agent = await h.create();
  h.client.sessions[0].push(turnStarted("busy"));
  expect(await h.run()).toBe("deferred");
  const throwing = await archiveByScope(
    { agentManager: h.manager, agentStorage: h.storage, listActiveWorkspaces: async () => [{ workspaceId: h.workspaceId, cwd: h.root, kind: "worktree" }], findWorkspaceIdForCwd: async () => null, markWorkspaceArchiving: () => { throw new Error("boom"); }, clearWorkspaceArchiving: () => {}, emitWorkspaceUpdatesForWorkspaceIds: async () => {}, sessionLogger: logger, paseoHome: "/nonexistent" } as never,
    { scope: { kind: "workspace", workspaceId: h.workspaceId }, requestId: "x", abortIf: () => null, holdNewRuns: () => h.manager.holdNewRunsForArchive(h.workspaceId, h.root), keepDirectory: true },
  ).then(() => "resolved", (e: Error) => e.message);
  const other = await h.create().then((a) => a.id, (e: Error) => e.message);
  console.log("Cc", { throwing, other, first: agent.id });
  expect(throwing).toBe("boom");
  expect(other).not.toContain("being archived");
});

test("R7 turn starts after requireIdle during archived-record write", async () => {
  const h = await setup("r7-post-check");
  const agent = await h.create();
  const session = h.client.sessions[0];
  let busyAtClose: boolean | null = null;
  session.onClose = async () => { busyAtClose = h.manager.hasInFlightRun(agent.id); };
  const upsert = h.storage.upsert.bind(h.storage);
  let armed = true;
  vi.spyOn(h.storage, "upsert").mockImplementation(async (record) => {
    if (armed && record.id === agent.id && record.archivedAt) {
      armed = false;
      session.push(turnStarted("post-check"));
    }
    return upsert(record);
  });
  const outcome = await h.run();
  console.log("R7-post-check", { armed, outcome, busyAtClose, archived: [...h.archived], closed: session.closed });
  expect(armed).toBe(false);
  expect(outcome).toBe("deferred");
  expect(busyAtClose).toBe(false);
});

test("R7 internal completion is invisible to auto-archive global subscription", async () => {
  const h = await setup("r7-internal-retry");
  const agent = await h.create(h.root, { internal: true });
  const events: string[] = [];
  h.manager.subscribe((event) => {
    if (event.type === "agent_state") events.push(`${event.agent.id}:${event.agent.lifecycle}`);
  }, { replayState: false });
  const session = h.client.sessions[0];
  session.push(turnStarted("working"));
  await new Promise((r) => setTimeout(r, 20));
  const outcome = await h.run();
  session.push({ type: "turn_completed", provider: "codex", turnId: "working" } as AgentStreamEvent);
  await new Promise((r) => setTimeout(r, 20));
  const busyAfter = h.manager.hasInFlightRun(agent.id);
  const normal = await h.create(path.dirname(h.root), {}, "ws-other");
  h.client.sessions[1].push(turnStarted("control"));
  h.client.sessions[1].push({ type: "turn_completed", provider: "codex", turnId: "control" } as AgentStreamEvent);
  await new Promise((r) => setTimeout(r, 20));
  console.log("R7-internal-retry", { outcome, busyAfter, internalEvents: events.filter((e) => e.startsWith(agent.id)), controlEvents: events.filter((e) => e.startsWith(normal.id)) });
  expect(outcome).toBe("deferred");
  expect(events).toContain(`${normal.id}:idle`);
  expect(events).toContain(`${agent.id}:idle`);
});
