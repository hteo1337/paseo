# Patch 0020 — adversarial review, round 7

Scope: `23a3f257c..b27d74dcb` (`d07f97000`, `b27d74dcb`). Production source was not edited. **Two P2 findings; no P1 or P3 found in this delta.** The round-6 A1 and A2 failures now defer, but the auto path can still close a newly busy agent and can strand an archive deferred by an internal agent.

## Findings

### P2 — A turn starting after `requireIdle` is archived and killed

`packages/server/src/server/agent/agent-manager.ts:1798-1804` checks `hasInFlightRun` once, then awaits `markRecordArchived`; that method awaits `registry.upsert`, invokes state and archive callbacks (`:1858-1904`), and only afterward does `closeAgentRuntime` drain events and close the session (`:1717-1727`). A provider-originated `turn_started` during the archived-record write crosses the last check. `workspace-archive-service.ts:420-429` sees the resulting *closed* agent and allows `archiveWorkspaceRecord`, so this fails open on the auto path.

Reproducer: `handoffs/round6-probes.test.ts:291` (`R7 turn starts after requireIdle during archived-record write`), run from root with `NOFILTER=1 npx vitest run --config packages/server/vitest.config.ts handoffs/round6-probes.test.ts -t 'R7 turn'`. The probe deliberately asserts the desired deferral, so exit 1 is the defect signal:

```text
R7-post-check { armed: false, outcome: 'archived', busyAtClose: true,
  archived: [ 'ws-r7-post-check' ], closed: true }
Expected: "deferred"; Received: "archived"
Tests  1 failed | 8 skipped (9)
```

Control: the round-6 A1 probe injects the same event during `applySnapshot`, before `requireIdle`; it now returns `deferred`, leaves the session open, and archives no workspace. The round-6 A1c pre-archive control also defers.

### P2 — Internal-agent deferral can exhaust retries before its completion is visible

`archive-if-safe.ts:169-180` now defers on a busy internal agent. `auto-archive-on-merge/index.ts:164-181` retries deferred work when its global `agent_state` subscriber sees an idle state. `agent-manager.ts:5083-5093` filters every internal agent event from global subscribers. The timer in `index.ts:50-68` makes only five retries (5 seconds, then four 30-second intervals); once those expire, an internal agent that finishes later emits no event that can resume this archive. A later unrelated agent event or git snapshot could rescue it, but a quiet daemon has no scheduled retry. The workspace remains active indefinitely despite the internal agent becoming idle.

Reproducer: `handoffs/round6-probes.test.ts:313` (`R7 internal completion is invisible to auto-archive global subscription`), run with `NOFILTER=1 npx vitest run --config packages/server/vitest.config.ts handoffs/round6-probes.test.ts -t 'R7 internal completion'`. The desired internal completion event assertion fails; a normal agent is the positive control:

```text
R7-internal-retry { outcome: 'deferred', busyAfter: false,
  internalEvents: [], controlEvents: [ '…:initializing', '…:idle', '…:running', '…:idle' ] }
Tests  1 failed | 9 skipped (10)
```

The existing `handoffs/round6-deferral-probes.test.ts:71` proves the retry cap with fake timers (six calls total, initial plus five). The reproducer uses a real `AgentManager`, storage, worktree and archive path; it does not wait 125 seconds for a real timer, so the indefinite outcome follows from the bounded scheduler and absent subscriber event.

## Requested checks

1. **Round-6 A1/A2:** Both now defer. Unchanged round-6 probes, `NOFILTER=1 npx vitest run --config packages/server/vitest.config.ts handoffs/round6-probes.test.ts -t 'A1|A2'`, exited 1 because their *old defect assertions* expect `archived`: `A1 { outcome:'deferred', busyAtClose:null, archived:[] }`; `A2 internal=true { busy:true, outcome:'deferred', archived:[], lifecycle:'running', closed:false }`. A1c and non-internal A2 controls passed. Result: **2 failed (stale expectations), 2 passed, 4 skipped** (`handoffs/round7-a1-a2.log`). Nothing found at those injection points.
2. **`requireIdle`, holds, marks, partial closes:** The P2 post-check race above is a busy close. The `AgentBusyDuringArchiveError` itself throws before `markRecordArchived` and `closeAgentRuntime`; `archiveByScope` releases the hold and clears the archiving mark in `finally` (`workspace-archive-service.ts:217-226`), and `index.ts:145-160` clears `inFlightCwds` in its flight `finally`. The round-6 settled-exit control reran green. Nothing found for a settled `AgentBusyDuringArchiveError` leaking those sets/marks or half-closing an agent. The old unbounded `session.close()` wait remains outside this delta.
3. **Idle internal teardown and manual parity:** `workspace-archive-service.ts:603-628` selects live agents by exact `workspaceId`; a foreign internal agent sharing the folder is excluded. Busy target internal agents are covered by the two busy checks, subject to the P2 window above. The only added teardown selection is an idle internal agent in the target workspace. Parent cascade detaches cross-workspace children (`agent-manager.ts:1846-1853`). No direct dependence by another subsystem on such an idle target agent was established. The manual path still uses `listAgents()` and passes `requireIdle:false`; its four round-6 manual probes passed again (4/4), and the substantive manual path matches `23a3f257c`. The archive call now passes an options object, so literal call arguments are not byte-identical. Nothing found for a manual behavioral change.
4. **Post-teardown deferral:** P2 internal completion can strand it after the finite retry budget. The active record is preserved on post-teardown deferral (`workspace-archive-service.ts:429-430`); a failed or busy live agent is seen by the nonclosed scan. Nothing found for a missing workspace record on this deferral path.
5. **Fail-open or folder removal:** P2 post-check race is fail-open. Nothing found that deletes the worktree: auto requests `keepDirectory:true` (`archive-if-safe.ts:139`), and `finishArchiveDirectory` returns before deletion (`workspace-archive-service.ts:452-461`). The round-6 real worktree folder and settled-hold controls reran green (2/2). Stored-only teardown failures that can be swallowed by `Promise.allSettled` predate the reviewed delta.

## Verification

- Requested focused command from `packages/server`: **7 files, 293 tests passed**, exit 0, 14.78s (`handoffs/round7-suite.log`).
- `npm run typecheck:server` from root: **exit 0**; relay, protocol, client, server and CLI typechecks completed (`handoffs/round7-typecheck.log`).
- The new probes intentionally assert the desired behavior and fail as shown. Providers are deterministic fakes; storage, git worktrees, `AgentManager`, `archiveIfSafe` and `archiveByScope` are real. No full suite, daemon, CI job or authenticated provider was exercised.
