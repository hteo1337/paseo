# Patch 0020 — adversarial review, round 6

Reviewed `60429185f..23a3f257c` (HEAD `23a3f257c`). No production source was modified (`git diff --exit-code` exit 0; only `handoffs/` and this file are untracked).

**No P1. Two P2 and four P3 findings.** Nothing reproduced for B (directory removal) or D (manual archive change). Auto-archive never deleted or emptied the folder in any probe. Nothing reproduced for hold leaks on settled exits. Both P2 findings are cases where auto-archive proceeds while an agent is working. Neither can lose the folder now, because `keepDirectory: true` is honoured.

## Findings

### P2 — A provider-originated turn that starts after the last busy check is killed by teardown

**Where:** `packages/server/src/server/workspace-archive-service.ts:168` is the last `abortIf`. Teardown `archiveAgent` at `:619` then runs `agent-manager.ts:1770` (`registry.applySnapshot`), `markRecordArchived` and `drainSessionEvents`, and only then `session.close()` at `agent-manager.ts:1718`. The hold (`holdNewRunsForArchive`) blocks only `streamAgent`, create, resume and register. It cannot stop a provider emitting `turn_started` on its own. After `:168` nothing re-checks, so the agent is closed mid-turn and the archive reports success.

**Probe:** `handoffs/round6-probes.test.ts:184`. Real AgentManager, AgentStorage, archiveIfSafe, archiveByScope and git worktree. The provider pushes `turn_started` from inside the first teardown `applySnapshot`, and the test records `hasInFlightRun` when `session.close()` runs.
```
A1 { outcome: 'archived', busyAtClose: true, archived: [ 'ws-a1' ] }
A1c { outcome: 'deferred', busy: true }     # control (:208): same event before archiveIfSafe
```
Control and treatment differ only in when the event arrives. The patch's own test ("auto archive defers when a provider starts a turn after the run hold") only covers turns that start before the second `abortIf`.

### P2 — Internal agents are still invisible to the auto-archive busy check (round-5 P1, downgraded)

**Where:** `archive-if-safe.ts:169`, `workspace-archive-service.ts:418` and `:599` all use `listAgents()`, which drops `internal` agents (`agent-manager.ts:995`). A working internal agent in the target workspace does not defer the archive. Teardown does not close it either. The workspace record is archived while the agent keeps running there. With `keepDirectory` the folder survives, so this is no longer the round-5 deletion.

**Probe:** `handoffs/round6-probes.test.ts:218`. `internal` is the only thing that changes between the two runs:
```
A2 { internal: true,  busy: true, outcome: 'archived', archived: ['ws-a2-true'], lifecycle: 'running', closed: false }
A2 { internal: false, busy: true, outcome: 'deferred', archived: [],             lifecycle: 'running', closed: false }
```

### P3 — A stuck target close holds the workspace indefinitely

**Where:** the hold is released in `finally` (`workspace-archive-service.ts:217-225`). But `archiveAgent` → `closeAgentRuntime` → `session.close()` (`agent-manager.ts:1718`) has no timeout. Reload has one (3 s); archive does not. If a provider close never settles, the hold, the "archiving" mark and `inFlightCwds` all stay set until the daemon restarts. New runs in that workspace are refused, and no retry is ever scheduled.

**Probe:** `handoffs/round6-probes.test.ts:260`. After 1.5 s the archive is still pending and a new create is refused:
```
C { settled: false, createErr: 'Agent … workspace is being archived', active: true }
```
This is not a missed release on an exit path. It is a missing bound on the path. Every settled exit releases the hold (see C below).

### P3 — A create already launching when the archive starts registers into the archived workspace

**Where:** the hold lasts only while the archive runs (`workspace-archive-service.ts:147` to `:224`). The busy check cannot see a launch that has not registered yet. If the provider launch outlasts the archive, `registerSession`'s check (`agent-manager.ts:3520`) runs after the hold is released and passes. The result is a live, promptable agent attached to an archived workspace record.

**Probe:** `handoffs/round6-probes.test.ts:231`:
```
A3 { outcome: 'archived', archived: ['ws-a3'], agentWs: 'ws-a3', lifecycle: 'idle' }   # streamAgent then succeeds
```
The existing test "an in-flight creation cannot register after an archive hold begins" is the control. It passes because that launch finishes while the hold is still active.

### P3 — Reload has no early admission check and closes the live session before it is refused

**Where:** `reloadAgentSessionInternal` closes the existing session at `agent-manager.ts:1567` and persists it as closed. Only then does it reach the hold check in `registerSession` (`:3520`). Create and resume reject before any side effect. A reload into a held root instead leaves the agent closed and gone from the manager, not merely refused.

**Probe:** `handoffs/round6-hold-probes.test.ts:88`:
```
A-reload { into: '… workspace is being archived', afterLive: 'gone', storedLifecycle: 'closed',
           storedArchived: null, resumeRefused: '… being archived', control: 'ok cwd=…/wt' }
```
`resumeRefused` is mislabelled: it is actually a second `createAgent` into the held root. The control reloads a different agent into the same root after the hold is released, and succeeds. The refusal itself is correct, since this is the construction working. The finding is the destructive order of operations.

### P3 — Retries triggered by agent events are uncapped

**Where:** `auto-archive-on-merge/index.ts:172-178`. Every non-running `agent_state` event, from any agent in the daemon, resets `retryAttemptsByCwd` and re-runs every deferred cwd. The five-attempt cap only limits the timer chain. Each real attempt runs `isPaseoOwnedWorktreeCwd`, which spawns a git subprocess (`utils/worktree.ts:953`). It also writes the "Deferred … still working" log line again.

**Probe:** `handoffs/round6-deferral-probes.test.ts:49`. Unrelated agents at `/elsewhere` emit 200 idle events while an archive stays deferred:
```
E1  { eventDriven: 201, afterTimers: 207 }
E1c { calls: 6 }        # control (:71): no events → 1 + 5 capped timer retries
```
This costs work and log noise; nothing incorrect happens.

## Requested items

- **A (admission bypass):** P2 A1, P2 A2, P3 in-flight create and P3 reload above. Nothing found for these:
  - create or resume starting during the hold;
  - a registration finishing during the hold;
  - a reload moving cwd into the root (refused, see the reload finding);
  - a foreign non-closed agent under the root (it defers).
- **B (auto-archive removes or empties the directory):** Nothing found. `handoffs/round6-probes.test.ts:249` ran a real worktree through the real archiveIfSafe path. It returned `archived`, and the directory listing was `['.git','work.txt']` both before and after. Deletion (`deletePaseoWorktree`) and teardown commands are reachable only through `maybeRemoveDirectory`, which `finishArchiveDirectory` skips when `keepDirectory` is set (`workspace-archive-service.ts:454`). No other `deletePaseoWorktree` caller exists in the server source.
- **C (hold leaks):** Nothing found on settled exits. Each of these released the hold, and a later create succeeded:
  - late `abortIf` returning `"cancelled"` (`round6-hold-probes.test.ts:63`);
  - late `abortIf` returning deferred agents (same test);
  - a throw from `markWorkspaceArchiving` inside the `try` (`round6-probes.test.ts:276`);
  - an early deferral, which never takes the hold.

  The unbounded case is the P3 stuck-close finding above.
- **D (manual archive vs 60429185f):** Nothing found. `handoffs/round6-manual-probes.test.ts` ran unchanged on HEAD and on a detached checkout of `60429185f` (removed afterwards). It covered four cases: foreign-idle, target-idle, target-running, and a foreign agent running in a child directory. The output lines are byte-identical (`handoffs/round6-manual-head.log`, `handoffs/round6-manual-baseline.log`). For example, in both trees `foreign-running-child` → `removedDirectory:true, agentLifecycle:"running"`. That is manual archive deleting under a running foreign agent, and it predates this patch. `maybeRemoveDirectory` is textually identical between the two commits.
- **E (retry loop):**
  - Unbounded retries: the P3 finding above.
  - Stranding: nothing found. A deferral returned after teardown now comes back before `archiveWorkspaceRecord`, so the record stays active and retries still find it; this fixes the round-5 P2 by construction.
  - Work after dispose: nothing found. `round6-deferral-probes.test.ts:86` disposed with a pending timer, a queued event replay and an in-flight archive. There were exactly 2 calls, both before dispose.

## What ran

| Command | Result |
|---|---|
| `cd packages/server && NOFILTER=1 npx vitest run src/server/auto-archive-on-merge src/server/workspace-archive-service.test.ts src/server/agent/agent-manager.test.ts src/utils/path.test.ts` | **7 files, 287 tests passed**, 20.7 s (`handoffs/round6-suite.log`) |
| `npm run typecheck:server` (root) | exit 0 (`handoffs/round6-typecheck.log`) |
| `NOFILTER=1 npx vitest run --config packages/server/vitest.config.ts handoffs/round6-{probes,hold-probes,deferral-probes,manual-probes}.test.ts` (from the worktree root) | **4 files, 18 tests passed** (`handoffs/round6-probes-final.log`) |
| Same manual probe on a `60429185f` checkout | 4 passed, same output (`handoffs/round6-manual-baseline.log`) |

The probe command in the brief is wrong as written. Running `npx vitest run --config vitest.config.ts ../../handoffs/<file>` from `packages/server` prints "No test files found" and exits 1, because vitest's root is `packages/server`. The root-relative form in the table works.

Probes whose name states a defect are written to pass when the defect reproduces. Each has a control that differs only in the variable under test, and both outcomes are quoted above.

Limits:
- Providers are deterministic fakes. Storage, archive, worktree creation and git are real.
- Lint was not run on the probe files; round 5 showed they fail repo lint.
- No daemon, CI job or authenticated provider was exercised.
