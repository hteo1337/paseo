// E: deferral/retry loop in auto-archive-on-merge/index.ts.
import { resolve } from "node:path";
import type { Logger } from "pino";
import { expect, test, vi } from "vitest";

import type { ArchiveIfSafeOutcome } from "../packages/server/src/server/auto-archive-on-merge/archive-if-safe.js";
import {
  setupAutoArchiveOnMerge,
  type AutoArchiveOnMergeDependencies,
  type AutoArchiveOnMergeOptions,
} from "../packages/server/src/server/auto-archive-on-merge/index.js";
import type { AgentManagerEvent, ManagedAgent } from "../packages/server/src/server/agent/agent-manager.js";
import type { WorkspaceGitRuntimeSnapshot } from "../packages/server/src/server/workspace-git-service.js";

const CWD = "/repo/wt";
const snap = (state: "open" | "merged") =>
  ({
    cwd: CWD,
    git: { isGit: true, isDirty: false, aheadOfOrigin: 0 },
    forge: { pullRequest: { url: "https://x/pull/1", state, isMerged: state === "merged" } },
  }) as unknown as WorkspaceGitRuntimeSnapshot;

function journey(outcome: () => Promise<ArchiveIfSafeOutcome>) {
  let onSnap: ((s: WorkspaceGitRuntimeSnapshot) => void) | null = null;
  let onAgent: ((e: AgentManagerEvent) => void) | null = null;
  const options = {
    logger: { child: () => ({ warn: vi.fn(), info: vi.fn() }) } as unknown as Logger,
    daemonConfigStore: { get: () => ({ autoArchiveAfterMerge: true }) },
    agentManager: {
      subscribe: (cb: (e: AgentManagerEvent) => void) => ((onAgent = cb), () => (onAgent = null)),
    },
    workspaceGitService: {
      onSnapshotUpdated: (l: (s: WorkspaceGitRuntimeSnapshot) => void) => ((onSnap = l), { unsubscribe() {} }),
      getSnapshot: async () => snap("merged"),
    },
    listActiveWorkspaces: async () => [{ workspaceId: "ws", cwd: CWD }],
  } as unknown as AutoArchiveOnMergeOptions;
  const archiveIfSafe = vi.fn(async () => outcome());
  const sub = setupAutoArchiveOnMerge(options, { archiveIfSafe, resolvePath: resolve } as unknown as AutoArchiveOnMergeDependencies);
  return {
    archiveIfSafe,
    sub,
    snap: (s: WorkspaceGitRuntimeSnapshot) => onSnap?.(s),
    unrelatedIdle: (i: number) =>
      onAgent?.({ type: "agent_state", agent: { id: `unrelated-${i}`, cwd: "/elsewhere", lifecycle: "idle" } as ManagedAgent }),
  };
}

test("E1 retries driven by unrelated agents' idle events have no cap", async () => {
  vi.useFakeTimers();
  try {
    const j = journey(async () => "deferred");
    j.snap(snap("open"));
    j.snap(snap("merged"));
    await vi.advanceTimersByTimeAsync(0);
    for (let i = 0; i < 200; i++) {
      j.unrelatedIdle(i);
      await vi.advanceTimersByTimeAsync(1);
    }
    const eventDriven = j.archiveIfSafe.mock.calls.length;
    await vi.advanceTimersByTimeAsync(10 * 60_000);
    const total = j.archiveIfSafe.mock.calls.length;
    console.log("E1", { eventDriven, afterTimers: total });
    j.sub.unsubscribe();
    expect(eventDriven).toBeGreaterThan(100);
  } finally {
    vi.useRealTimers();
  }
});

test("E1 control: without events only the capped timer chain runs", async () => {
  vi.useFakeTimers();
  try {
    const j = journey(async () => "deferred");
    j.snap(snap("open"));
    j.snap(snap("merged"));
    await vi.advanceTimersByTimeAsync(60 * 60_000);
    console.log("E1c", { calls: j.archiveIfSafe.mock.calls.length });
    j.sub.unsubscribe();
    expect(j.archiveIfSafe).toHaveBeenCalledTimes(6);
  } finally {
    vi.useRealTimers();
  }
});

test("E2 no archiveIfSafe after dispose: pending timer, queued event replay, and in-flight flight", async () => {
  vi.useFakeTimers();
  try {
    let resolveFlight!: (o: ArchiveIfSafeOutcome) => void;
    let calls = 0;
    const j = journey(() => {
      calls += 1;
      return calls === 2 ? new Promise((r) => (resolveFlight = r)) : Promise.resolve("deferred");
    });
    j.snap(snap("open"));
    j.snap(snap("merged"));
    await vi.advanceTimersByTimeAsync(5_000); // timer retry -> call 2 in flight
    expect(calls).toBe(2);
    j.unrelatedIdle(1); // queued replay (setImmediate) + retryAfterFlight
    j.sub.unsubscribe();
    resolveFlight("deferred");
    await vi.advanceTimersByTimeAsync(60 * 60_000);
    console.log("E2", { calls });
    expect(calls).toBe(2);
  } finally {
    vi.useRealTimers();
  }
});
