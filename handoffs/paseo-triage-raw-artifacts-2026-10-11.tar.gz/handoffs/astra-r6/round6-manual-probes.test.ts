// D: manual archive outcomes; run unchanged on HEAD and on a 60429185f checkout.
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import pino from "pino";
import { afterEach, test } from "vitest";

import { AgentManager } from "../packages/server/src/server/agent/agent-manager.js";
import { AgentStorage } from "../packages/server/src/server/agent/agent-storage.js";
import type {
  AgentClient,
  AgentSessionConfig,
  AgentStreamEvent,
} from "../packages/server/src/server/agent/agent-sdk-types.js";
import { archiveByScope } from "../packages/server/src/server/workspace-archive-service.js";
import { createWorktree } from "../packages/server/src/utils/worktree.js";

const logger = pino({ level: "silent" });
const cleanup: string[] = [];
afterEach(() => {
  for (const p of cleanup.splice(0)) rmSync(p, { recursive: true, force: true });
});
const CAPS = {
  supportsStreaming: false,
  supportsSessionPersistence: false,
  supportsSessionListing: false,
  supportsDynamicModes: false,
  supportsMcpServers: false,
  supportsReasoningStream: false,
  supportsToolInvocations: false,
};
function makeClient(sessions: Array<{ push: (e: AgentStreamEvent) => void; closed: boolean }>) {
  const mk = (config: AgentSessionConfig) => {
    const subs = new Set<(e: AgentStreamEvent) => void>();
    const id = `s-${Math.random().toString(36).slice(2)}`;
    const s = {
      provider: "codex",
      capabilities: CAPS,
      id,
      closed: false,
      config,
      run: async () => ({ sessionId: id, finalText: "", timeline: [] }),
      startTurn: async () => ({ turnId: "t" }),
      subscribe: (cb: (e: AgentStreamEvent) => void) => (subs.add(cb), () => subs.delete(cb)),
      push: (e: AgentStreamEvent) => subs.forEach((cb) => cb(e)),
      streamHistory: async function* () {},
      getRuntimeInfo: async () => ({ provider: "codex", sessionId: id, model: null, modeId: null }),
      getAvailableModes: async () => [],
      getCurrentMode: async () => null,
      setMode: async () => {},
      getPendingPermissions: () => [],
      respondToPermission: async () => {},
      describePersistence: () => ({ provider: "codex", sessionId: id }),
      interrupt: async () => {},
      close: async () => void (s.closed = true),
    };
    sessions.push(s);
    return s;
  };
  return {
    provider: "codex",
    capabilities: CAPS,
    isAvailable: async () => true,
    fetchCatalog: async () => ({ models: [{ provider: "codex", id: "m", label: "m", isDefault: true }], modes: [] }),
    createSession: async (c: AgentSessionConfig) => mk(c),
    resumeSession: async (_h: unknown, c?: Partial<AgentSessionConfig>) => mk({ provider: "codex", cwd: c?.cwd ?? "/" } as AgentSessionConfig),
  } as unknown as AgentClient;
}

async function scenario(name: string, kind: "foreign-idle" | "target-idle" | "target-running" | "foreign-running-child") {
  const tempDir = mkdtempSync(path.join(tmpdir(), "p0020-r6-d-"));
  cleanup.push(tempDir);
  const repoDir = path.join(tempDir, "repo");
  mkdirSync(repoDir);
  const git = (...a: string[]) => execFileSync("git", a, { cwd: repoDir, stdio: "pipe" });
  git("init", "-b", "main");
  git("config", "user.email", "t@t");
  git("config", "user.name", "t");
  git("-c", "commit.gpgsign=false", "commit", "--allow-empty", "-m", "i");
  const paseoHome = path.join(tempDir, ".paseo");
  const wt = await createWorktree({ cwd: repoDir, worktreeSlug: name, source: { kind: "branch-off", baseBranch: "main", branchName: name }, runSetup: false, paseoHome });
  const root = wt.worktreePath;
  const sessions: Array<{ push: (e: AgentStreamEvent) => void; closed: boolean }> = [];
  const storage = new AgentStorage(path.join(tempDir, "agents"), logger);
  const manager = new AgentManager({ clients: { codex: makeClient(sessions) }, registry: storage, logger });
  const workspaceId = `ws-${name}`;
  const archived = new Set<string>();
  const foreign = kind.startsWith("foreign");
  let cwd = root;
  if (kind === "foreign-running-child") {
    cwd = path.join(root, "child");
    mkdirSync(cwd);
  }
  const agent = await manager.createAgent({ provider: "codex", cwd } as AgentSessionConfig, undefined, { workspaceId: foreign ? "ws-other" : workspaceId });
  if (kind.endsWith("running") || kind === "foreign-running-child") {
    sessions[0].push({ type: "turn_started", provider: "codex", turnId: "x" } as AgentStreamEvent);
    await new Promise((r) => setTimeout(r, 20));
  }
  let error: string | null = null;
  const result = await archiveByScope(
    {
      paseoHome,
      github: { invalidate: () => {} },
      workspaceGitService: { getSnapshot: async () => null },
      agentManager: manager,
      agentStorage: storage,
      findWorkspaceIdForCwd: async () => null,
      listActiveWorkspaces: async () => (archived.has(workspaceId) ? [] : [{ workspaceId, cwd: root, kind: "worktree" }]),
      archiveWorkspaceRecord: async (id: string) => void archived.add(id),
      emitWorkspaceUpdatesForWorkspaceIds: async () => {},
      markWorkspaceArchiving: () => {},
      clearWorkspaceArchiving: () => {},
      killTerminalsForWorkspace: async () => {},
      sessionLogger: logger,
    } as never,
    { scope: { kind: "workspace", workspaceId }, requestId: "manual" },
  ).catch((e: Error) => ((error = e.message), null));
  console.log(
    `D ${kind} ${JSON.stringify({
      archivedWorkspaceIds: result?.archivedWorkspaceIds,
      archivedAgentIds: result?.archivedAgentIds.length,
      removedDirectory: result?.removedDirectory,
      deferredByAgentIds: (result as { deferredByAgentIds?: string[] } | null)?.deferredByAgentIds ?? null,
      dirExists: existsSync(root),
      agentClosed: sessions[0].closed,
      agentLifecycle: manager.getAgent(agent.id)?.lifecycle ?? "gone",
      error,
    })}`,
  );
}

for (const kind of ["foreign-idle", "target-idle", "target-running", "foreign-running-child"] as const) {
  test(`D manual ${kind}`, async () => {
    await scenario(kind, kind);
  });
}
