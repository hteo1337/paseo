// C: hold release on late-abort exits; A: reload moving cwd into a held root.
import { mkdirSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import pino from "pino";
import { afterEach, expect, test } from "vitest";

import { AgentManager } from "../packages/server/src/server/agent/agent-manager.js";
import { AgentStorage } from "../packages/server/src/server/agent/agent-storage.js";
import type { AgentClient, AgentSessionConfig, AgentStreamEvent } from "../packages/server/src/server/agent/agent-sdk-types.js";
import { archiveByScope } from "../packages/server/src/server/workspace-archive-service.js";

const logger = pino({ level: "silent" });
const cleanup: string[] = [];
afterEach(() => cleanup.splice(0).forEach((p) => rmSync(p, { recursive: true, force: true })));
const CAPS = { supportsStreaming: false, supportsSessionPersistence: false, supportsSessionListing: false, supportsDynamicModes: false, supportsMcpServers: false, supportsReasoningStream: false, supportsToolInvocations: false };
const sessions: Array<{ push: (e: AgentStreamEvent) => void }> = [];
function session(config: AgentSessionConfig) {
  const subs = new Set<(e: AgentStreamEvent) => void>();
  const id = `s-${Math.random().toString(36).slice(2)}`;
  const s = {
    provider: "codex", capabilities: CAPS, id, config,
    run: async () => ({ sessionId: id, finalText: "", timeline: [] }),
    startTurn: async () => ({ turnId: "t" }),
    subscribe: (cb: (e: AgentStreamEvent) => void) => (subs.add(cb), () => subs.delete(cb)),
    push: (e: AgentStreamEvent) => subs.forEach((cb) => cb(e)),
    streamHistory: async function* () {},
    getRuntimeInfo: async () => ({ provider: "codex", sessionId: id, model: null, modeId: null }),
    getAvailableModes: async () => [], getCurrentMode: async () => null, setMode: async () => {},
    getPendingPermissions: () => [], respondToPermission: async () => {},
    describePersistence: () => ({ provider: "codex", sessionId: id }),
    interrupt: async () => {}, close: async () => {},
  };
  sessions.push(s);
  return s;
}
const client = {
  provider: "codex", capabilities: CAPS, isAvailable: async () => true,
  fetchCatalog: async () => ({ models: [{ provider: "codex", id: "m", label: "m", isDefault: true }], modes: [] }),
  createSession: async (c: AgentSessionConfig) => session(c),
  resumeSession: async (_h: unknown, c?: Partial<AgentSessionConfig>) => session({ provider: "codex", cwd: c?.cwd ?? "/" } as AgentSessionConfig),
} as unknown as AgentClient;

function setup() {
  const tempDir = mkdtempSync(path.join(tmpdir(), "p0020-r6-hold-"));
  cleanup.push(tempDir);
  const root = path.join(tempDir, "wt");
  const outside = path.join(tempDir, "outside");
  mkdirSync(root);
  mkdirSync(outside);
  const storage = new AgentStorage(path.join(tempDir, "agents"), logger);
  const manager = new AgentManager({ clients: { codex: client }, registry: storage, logger });
  const deps = {
    paseoHome: path.join(tempDir, ".paseo"), github: { invalidate() {} }, workspaceGitService: { getSnapshot: async () => null },
    agentManager: manager, agentStorage: storage, findWorkspaceIdForCwd: async () => null,
    listActiveWorkspaces: async () => [{ workspaceId: "ws", cwd: root, kind: "worktree" }],
    archiveWorkspaceRecord: async () => {}, emitWorkspaceUpdatesForWorkspaceIds: async () => {},
    markWorkspaceArchiving: () => {}, clearWorkspaceArchiving: () => {}, killTerminalsForWorkspace: async () => {}, sessionLogger: logger,
  };
  return { root, outside, storage, manager, deps };
}

test.each(["cancelled", "deferred"] as const)("C late abort (%s) after hold releases it", async (reason) => {
  const h = setup();
  let late = false;
  const list = h.storage.listByWorkspace.bind(h.storage);
  h.storage.listByWorkspace = async (id: string) => ((late = true), list(id));
  let heldDuring: string | null = null;
  const result = await archiveByScope(h.deps as never, {
    scope: { kind: "workspace", workspaceId: "ws" }, requestId: "auto-archive-on-merge", keepDirectory: true,
    abortIf: () => {
      if (!late) return null;
      return reason === "cancelled" ? "cancelled" : ["late-agent"];
    },
    holdNewRuns: () => {
      const release = h.manager.holdNewRunsForArchive("ws", h.root);
      return () => {
        heldDuring = "released";
        release();
      };
    },
  });
  const created = await h.manager.createAgent({ provider: "codex", cwd: h.root } as AgentSessionConfig, undefined, { workspaceId: "ws" }).then(() => "ok", (e: Error) => e.message);
  console.log("C-late", { reason, result, heldDuring, created });
  expect(created).toBe("ok");
});

test("A reload into a held root is refused only after closing the live session", async () => {
  const h = setup();
  const agent = await h.manager.createAgent({ provider: "codex", cwd: h.outside } as AgentSessionConfig, undefined, { workspaceId: "other" });
  const ctrl = await h.manager.createAgent({ provider: "codex", cwd: h.outside } as AgentSessionConfig, undefined, { workspaceId: "other" });
  const release = h.manager.holdNewRunsForArchive("ws", h.root);
  const into = await h.manager.reloadAgentSession(agent.id, { cwd: h.root }).then((a) => `ok cwd=${a.cwd}`, (e: Error) => e.message);
  const afterLive = h.manager.getAgent(agent.id)?.lifecycle ?? "gone";
  const stored = await h.storage.get(agent.id);
  const resumeRefused = await h.manager.createAgent({ provider: "codex", cwd: h.root } as AgentSessionConfig, undefined, { workspaceId: "other" }).then(() => "ok", (e: Error) => e.message);
  release();
  const control = await h.manager.reloadAgentSession(ctrl.id, { cwd: h.root }).then((a) => `ok cwd=${a.cwd}`, (e: Error) => e.message);
  console.log("A-reload", { into, afterLive, storedLifecycle: stored?.lastStatus ?? null, storedArchived: stored?.archivedAt ?? null, resumeRefused, control });
  expect(into).toContain("being archived");
  expect(afterLive).toBe("gone");
  expect(resumeRefused).toContain("being archived");
  expect(control).toContain("ok");
});
