# Patch 0020 — adversarial review, round 5

Reviewed `f66aa6409..5dd854096` at HEAD `5dd854096402e92f731da643542a309418a0f04e`. **Three P1 findings and two P2 findings remain.** The specific round-4 late-arrival reproductions are fixed; the broader deletion-safety claim is not established by construction. No production source was modified.

## Findings

### P1 — Internal agents are invisible to every live-agent check

**Locations:** `packages/server/src/server/workspace-archive-service.ts:538`; `packages/server/src/server/auto-archive-on-merge/archive-if-safe.ts:169`; filtering implementation at `packages/server/src/server/agent/agent-manager.ts:995`.

Both guards call `listAgents()`, which deliberately excludes `internal` agents. An already-running internal agent under the root therefore neither defers auto-archive nor prevents final deletion; target teardown uses the same filtered inventory. Internal sessions are real product behavior, including checkout metadata generation (`packages/server/src/server/session/checkout/git-metadata-generator.ts:209`).

**Probe:** `handoffs/round5-probes.test.ts:39`, `internal-agent visibility control`. Create and start an internal foreign-workspace agent, verify `hasInFlightRun=true` but inventory length zero, then run real `archiveIfSafe` and real directory deletion. Result: `archived`, directory absent, agent still in flight. Change only `internal` to false: inventory length one, `deferred`, directory preserved. Safety inventory must include internal runtimes independently of public UI visibility.

### P1 — A registration already in flight outlives the hold and registers into the deleted directory

**Locations:** `packages/server/src/server/agent/agent-manager.ts:1259`, `:1281`, `:1403`, `:1575`, `:3520`; hold release at `packages/server/src/server/workspace-archive-service.ts:230`.

The initial admission check precedes asynchronous provider launch. Until `registerSession` inserts the session, archive sees no agent and does not wait for that outstanding launch. If launch settles after deletion and hold release, the final admission check succeeds; the earlier cwd existence check is not repeated. Reload can also change cwd into the target root while its replacement session is unregistered.

**Probe:** `handoffs/round5-probes.test.ts:51`, `registration already in flight survives archive`, for create, resume, and reload. Hold the provider adapter's launch promise after it has acquired a session; verify `listAgents()` is empty; archive actually deletes the directory while that session is live. Release launch afterward: registration succeeds as `idle` with a nonexistent cwd. The reload variant starts in an outside directory and changes cwd through the real `reloadAgentSession` API. Controls at `:27` launch create/resume during the hold: both reject and acquire zero sessions. Reserve/count pending launches before their first asynchronous operation and settle them before deletion; a registration-time hold check alone cannot enforce the claimed invariant.

### P1 — Successful ACP close does not establish process exit

**Locations:** `packages/server/src/server/agent/providers/acp-agent.ts:2450`, `:2454`; trusting session close at `packages/server/src/server/agent/agent-manager.ts:1724`; final check at `packages/server/src/server/workspace-archive-service.ts:507`.

ACP ignores the terminator's `kill-timeout` result for both terminal children and its main child. Its close resolves and drops process references, so AgentManager can archive/remove the runtime and the final inventory check permits deletion despite a surviving process. This provider behavior predates the delta; it is a counterexample to the new safety claim, not a claimed round-5 regression.

**Probe:** `handoffs/round5-close-probes.test.ts:9`. Use real ACP `createTerminal` to spawn an isolated Node process in the worktree; inject `kill-timeout` through its existing terminator port and wire real ACP close into the manager session adapter. Real archive deletes the directory and removes the agent, while `process.kill(pid, 0)` succeeds and both exit/signal codes remain null. The control delegates to real `terminateWithTreeKill`: the child has exited before deletion. The timeout outcome is injected, not a claim that SIGKILL naturally failed on this machine; both fixture children are terminated during cleanup. A failed termination must remain a failed close with retained ownership.

### P2 — Final deferral after record archive has no automatic cleanup retry

**Locations:** `packages/server/src/server/workspace-archive-service.ts:439`, `:507`; `packages/server/src/server/auto-archive-on-merge/index.ts:125`, `:144`; `packages/server/src/server/auto-archive-on-merge/archive-if-safe.ts:90`.

The workspace record and merged-PR marker are committed before the final check can return `deferredByAgentIds`. The retry then enumerates only active workspaces, finds none, and clears deferral; even a direct repeat of `archiveIfSafe` skips because the PR marker already matches. The folder remains orphaned from this auto-archive mechanism after the blocking agent closes.

**Probe:** `handoffs/round5-probes.test.ts:76`, `final deferral after record archive loses retry`. A registered foreign agent initially uses a symlink outside the root; terminal teardown repoints that symlink into the root, making the final realpath check defer. Real subscription, archive, storage callbacks and retry execute: record disappears from the active list, PR marker is set, folder remains, closing the foreign agent triggers another snapshot read but no second archive attempt, and direct retry returns `skipped`. This uses an explicit filesystem-identity change to reach the late guard; it does not mutate AgentManager internals. The ordinary pre-record deferral control at `:17` closes the blocker and then successfully deletes the folder. Keep cleanup work retryable independently of active-record enumeration and the completed-PR marker.

### P2 — Manual archive behavior changed despite no holdNewRuns

**Location:** `packages/server/src/server/workspace-archive-service.ts:507`.

The new final live-agent check is unconditional. A manual archive with a foreign idle agent at the root now archives the workspace record but returns `removedDirectory=false` and leaves the folder. Manual archive supplies neither the auto hold nor the auto retry machinery; its prior behavior is not preserved.

**Probe:** `handoffs/round5-probes.test.ts:66`, `manual archive final check control`. At round 5, foreign-agent case retains the folder and returns that agent ID as a deferral; target-owned-agent control closes normally and removes the folder. The same probe on an untouched detached checkout of `f66aa6409` confirms the behavioral change: target-owned control passes, foreign-agent expectation fails because baseline returns `removedDirectory=true`. The baseline checkout was inspected and removed after recording its log. Preserve the intended manual contract or explicitly handle the changed cleanup outcome rather than treating this as unchanged behavior.

## Requested items

1. **Round-4 probes:** nothing found for the exact late-existing root, late-existing child, late-create, and late-resume windows. Unmodified child probes plus the root-only fixture variant execute eight P1 cases: the six late defect assertions now fail, while both early controls pass. Additional safety-oriented probes at `round5-probes.test.ts:17` and `:27` verify early deferral/preservation and create/resume rejection explicitly, rather than treating arbitrary probe failure as proof.
2. **No live agent at deletion:** not true; the three P1 findings above reproduce independent gaps. Nothing found in the inspected direct map-insertion path: the sole `agents.set` is immediately guarded at `agent-manager.ts:3520`. Nothing found for an ordinary completed registration changing its managed cwd in place; reload re-enters registration, but its unregistered replacement has the demonstrated launch gap. Provider shutdown coverage is specifically qualified above, not a blanket certification of every provider.
3. **Liveness/visibility:** late deferral loses automatic cleanup, as above. Nothing found for the claim that ordinary foreign-idle deferral has no log: `round5-probes.test.ts:104` proves six attempts each log the blocker ID and retain the active record, then closure permits deletion. A foreign idle agent intentionally blocks until closed under the chosen design; retries cap at five timers (`index.ts:48`), with qualifying agent events resetting attempts. The log says “still working” even when idle, but this is not reported as a separate defect.
4. **Manual archive:** changed in the foreign-agent case, as proven against the baseline. Nothing found in the target-owned-agent control. The accepted post-teardown unsubscribe decision is not re-reported as a finding; no additional P3 finding.

## Verification and limits

- `npm run build:server`: exit 0 after copying the missing installed `zod-aot` directory from round 4; `handoffs/round5-build.log`.
- Requested server command: **7 files, 284 tests passed**, 30.37s; `handoffs/round5-suite.log`.
- Round-4 P1-only rerun: **6 failed defect assertions, 2 passed controls**, 10 unrelated tests filtered out; `handoffs/round5-round4-rerun.log`. Command: `npx vitest run --config packages/server/vitest.config.ts handoffs/round4-probes.test.ts handoffs/round4-root-probes.test.ts -t 'P1 real deletion'`.
- New probes: **13 passed** across two files; `handoffs/round5-probes-final.log`. After adding reload and visibility cases, the targeted follow-up ran **4 passed** (create/resume repeated, reload/visibility added); `handoffs/round5-additional.log`. Together these execute all **15 unique current cases**. Run both current files with `npx vitest run --config packages/server/vitest.config.ts handoffs/round5-probes.test.ts handoffs/round5-close-probes.test.ts`.
- Manual baseline: **1 passed control, 1 expected failed round-5 behavior assertion**; `handoffs/round5-manual-baseline.log`. The first exploratory new-probe run exposed missing storage in the test fixture; it was corrected to real AgentStorage before the passing run. Those initial fixture failures are not findings.
- `npm run typecheck`: exit 0, `handoffs/round5-typecheck.log`. `npm run lint`: exit 1, **58 errors exclusively in retained handoffs probe/helper files** (explicit-any, unused names, shadowing, nested ternary), `handoffs/round5-lint.log`; lint is not green.
- `git diff --exit-code`: exit 0; only review artifacts are untracked. These are local review results, not CI or a solo merge gate. Provider launches use deterministic adapters; archive, worktree deletion, storage, and the ACP fixture subprocess are real. No production daemon or authenticated provider session was exercised.
