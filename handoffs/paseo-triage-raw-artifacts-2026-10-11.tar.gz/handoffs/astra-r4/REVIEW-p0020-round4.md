# Patch 0020 — adversarial review, round 4

Reviewed `60429185f..f66aa6409`, especially `726774d57..f66aa6409`, at HEAD `f66aa64093551b8b4a0990281162bfc397510371`. Two remaining findings: P1 and P3. Production source is unchanged (`git diff --stat` empty).

## Findings, ordered by severity

### P1 — The late busy check still precedes asynchronous teardown and deletion

**Locations:** `packages/server/src/server/workspace-archive-service.ts:168`, `:172`, `:557`, `:451`; provider admission at `packages/server/src/server/agent/agent-manager.ts:3766` and `:4558`.

After the late `abortIf`, `archiveWorkspaceContents` awaits agent archive and terminal shutdown; record archive, snapshot refresh, teardown commands, reference checks, and worktree deletion add more awaits. None rechecks busy agents, and the hold blocks `streamAgent` but still admits provider-originated starts and create/resume registration. Counting arrivals makes them visible to a subsequent check; it does not prevent a turn arriving after the last check.

**Deterministic reproduction:** `handoffs/round4-probes.test.ts:31`, cases `late-existing`, `late-create`, and `late-resume`. During terminal teardown, after exactly two abort checks, start an autonomous provider turn through the real AgentManager; ordinary `streamAgent` is demonstrably blocked by the hold. Real `archiveByScope` and real worktree deletion return `removedDirectory: true`, the directory is absent, and the agent remains `running` with `hasInFlightRun: true`.

The executed existing-agent case uses another workspaceId and cwd equal to the deleted root; create/resume cases register in the target workspace after its agent inventory was captured. The `early` control injects the same event during the first workspace-update await: the late check defers and preserves the directory. These are actual isolated fixture deletions, not a recording replacement for deletion.

**Evidence qualification:** after the successful nine-probe run, the existing-agent fixture was changed to use a `child` directory beneath the root (current lines 35–38). That variant was not rerun before the user's instruction to stop probes; the log proves the root-equal variant, not the child-directory variant. No further probe edits or runs were made after that instruction.

### P2 — Nothing found in the retry-reset or containment fixes

The old exhausted-retry/transient-read counterexample no longer reproduces, and `..cache` now remains held. Counter cleanup and containment coverage are detailed below.

### P3 — Unsubscribe after the late check still allows record archive and directory deletion

**Locations:** `packages/server/src/server/workspace-archive-service.ts:168`, `:381`, `:405`, `:451`; cancellation predicate at `packages/server/src/server/auto-archive-on-merge/archive-if-safe.ts:133`.

Cancellation is checked before record teardown, but does not reach `maybeRemoveDirectory` or its awaited operations. Unsubscribe while terminal shutdown is pending therefore returns before the continuation archives the workspace record and deletes its directory.

**Deterministic reproduction:** `handoffs/round4-probes.test.ts:58`, `P3 real unsubscribe at late await`. Real subscription disposal, `archiveIfSafe`, `archiveByScope`, and worktree deletion execute against a fixture: pause terminal shutdown, verify the directory exists, unsubscribe, then release; the record callback runs after unsubscribe, the directory disappears, and the outcome is `archived`. The `early` control pauses stored-record loading instead: disposal yields `skipped`, no record archive, and the directory survives.

## Claims 1–5

1. **Round-3 rerun:** 19 probes executed: 15 passed, four failed their assertions of defective behavior. The four failures establish that the earlier integrated teardown window, `..cache` admission, exhausted-retry/read-failure stranding, and ownership-await cancellation no longer reproduce. **Nothing found** for those four exact windows; however, the autonomous-turn probe and both create/resume replay probes still reproduce, so “each must now fail to reproduce” is not satisfied. The remaining twelve passing probes are controls.
2. **Await-to-deletion safety:** P1 above reproduces running-agent deletion after the late check, including a differently owned agent and agents created/resumed during the hold. **Nothing found** in the early-control window or ordinary `streamAgent` hold enforcement; both visibly prevent progress as intended. Descendant-only rerun remains unverified as qualified above.
3. **Pending counter leaks:** **Nothing found** in the exercised rejection and close-mid-tail cases (`handoffs/round4-probes.test.ts:83`). Both queue two starts behind a gate, prove counter 2 and busy true, then release with dispatch rejection or an already-requested real `closeAgent`; counter and event-tail entries disappear and busy becomes false. The catch/finally at `agent-manager.ts:3796–3813` and close's drain at `:1710` explain those results; a never-settling dependency was not proven recoverable.
4. **Other containment callers:** **Nothing found** in the changed separator-aware predicate (`packages/server/src/utils/path.ts:116`) or inspected callers in directory suggestions, workspace Git watching, and worktree cwd mapping. The deterministic matrix at `handoffs/round4-probes.test.ts:95` accepts ordinary and dot-prefixed descendants while rejecting parents, traversal, sibling prefixes, cross-drive paths, and Windows mixed-separator escapes; POSIX, drive-letter, and UNC dialects are covered. Windows lexical behavior was tested on macOS, not on a Windows filesystem; POSIX backslashes are deliberately not treated as separators.
5. **Cancellation:** P3 above remains reproducible. **Nothing found** for cancellation during ownership lookup (round-3 rerun) or stored-record loading (round-4 early control); both now prevent archive. This does not establish cancellation after the late check.

## Verification

- `npm run build:server`: initial failure because `zod-aot` was absent; copied the installed dependency from the round-3 checkout into this checkout's ignored `node_modules`, then rebuilt successfully (exit 0). Logs: `handoffs/round4-build.log`, `handoffs/round4-build-retry.log`.
- Requested command from `packages/server`: `npx vitest run src/server/auto-archive-on-merge src/server/workspace-archive-service.test.ts src/server/agent/agent-manager.test.ts src/utils/path.test.ts` — **7 files, 276 tests passed**, 38.08s (`handoffs/round4-suite.log`).
- Unmodified round-3 probes: `npx vitest run --config packages/server/vitest.config.ts handoffs/round3-probes.test.ts` — **15 passed, 4 failed**, 3.65s (`handoffs/round4-round3-rerun.log`); failure means the old defect assertion no longer holds.
- Round-4 probes: `npx vitest run --config packages/server/vitest.config.ts handoffs/round4-probes.test.ts` — **9 passed**, 6.73s (`handoffs/round4-probes.log`), subject to the subsequent fixture edit qualified above. Finding probes assert the observed defect; green confirms reproduction, not safety.
- These are local review results, not CI or a solo merge gate. Provider sessions and selected asynchronous dependencies are deterministic adapters; archive and deletion use real implementations. No live provider or production daemon was exercised, and no claim is made that every underlying defect originated in the round-4 delta.
