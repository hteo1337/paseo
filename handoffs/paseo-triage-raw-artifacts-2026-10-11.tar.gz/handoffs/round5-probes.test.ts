import { test, expect, vi } from 'vitest';
import { existsSync, mkdirSync, rmSync, symlinkSync, unlinkSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fixture } from './round5-fixture.js';
import { gate, tick, snapshot, logger } from './round4-helpers.js';
import { archiveByScope } from '../packages/server/src/server/workspace-archive-service.js';
import { archiveIfSafe } from '../packages/server/src/server/auto-archive-on-merge/archive-if-safe.js';
import { setupAutoArchiveOnMerge } from '../packages/server/src/server/auto-archive-on-merge/index.js';

function auto(f:any) {
  return archiveIfSafe({workspaceId:'w',snapshot:{...snapshot(),cwd:f.cwd},log:logger,
    options:{...f.deps,getAutoArchivedChangeRequestUrl:async()=>null},
    deps:{archiveByScope,isPaseoOwnedWorktreeCwd:async()=>({allowed:true,worktreePath:f.cwd}),
      killTerminalsForWorkspace:f.deps.killTerminalsForWorkspace}});
}

test.each(['root','child'])('round4 late-existing %s now defers before teardown',async(where)=>{
  const f=await fixture();try{
    const cwd=where==='root'?f.cwd:join(f.cwd,'child');if(where==='child')mkdirSync(cwd);
    const a=await f.m.createAgent({provider:'codex',cwd},undefined,{workspaceId:'other'});
    let teardown=false;f.deps.killTerminalsForWorkspace=async()=>{teardown=true;f.sessions[0].push({type:'turn_started',turnId:'late'})};
    expect(await auto(f)).toBe('deferred');expect(teardown).toBe(false);expect(existsSync(f.cwd)).toBe(true);
    await f.m.closeAgent(a.id);expect(await auto(f)).toBe('archived');expect(existsSync(f.cwd)).toBe(false);
  }finally{rmSync(f.base,{recursive:true,force:true})}
});

test.each(['create','resume'])('round4 late-%s blocked while terminal teardown awaits',async(mode)=>{
  const f=await fixture();try{
    let blocked=false;
    f.deps.killTerminalsForWorkspace=async()=>{
      const request=mode==='create'?f.m.createAgent({provider:'codex',cwd:f.cwd},undefined,{workspaceId:'w'}):
        f.m.resumeAgentFromPersistence({provider:'codex',sessionId:'saved'},{cwd:f.cwd},undefined,{workspaceId:'w'});
      await expect(request).rejects.toThrow('being archived');blocked=true;
    };
    expect(await auto(f)).toBe('archived');expect(blocked).toBe(true);expect(f.sessions).toHaveLength(0);
  }finally{rmSync(f.base,{recursive:true,force:true})}
});

test.each([false,true])('internal-agent visibility control internal=%s',async(internal)=>{
  const f=await fixture();try{
    const a=await f.m.createAgent({provider:'codex',cwd:f.cwd,internal},undefined,{workspaceId:'other'});
    f.sessions[0].push({type:'turn_started',turnId:'active'});await tick();
    expect(f.m.hasInFlightRun(a.id)).toBe(true);
    expect(f.m.listAgents().length).toBe(internal?0:1);
    expect(await auto(f)).toBe(internal?'archived':'deferred');
    expect(existsSync(f.cwd)).toBe(!internal);expect(f.m.hasInFlightRun(a.id)).toBe(true);
    await f.m.closeAgent(a.id);
  }finally{rmSync(f.base,{recursive:true,force:true})}
});

test.each(['create','resume','reload'])('registration already in flight survives archive: %s',async(mode)=>{
  const f=await fixture();const held=gate();let pending:any;let sessionLive=false;try{
    const old=mode==='reload'?await f.m.createAgent({provider:'codex',cwd:f.base},undefined,{workspaceId:'other'}):null;
    const original=f.c.createSession;
    f.c.createSession=async(config:any)=>{const s=await original(config);sessionLive=true;
      s.close=async()=>{sessionLive=false};await held.promise;return s;};
    pending=mode==='reload'?f.m.reloadAgentSession(old!.id,{cwd:f.cwd}):mode==='create'?f.m.createAgent({provider:'codex',cwd:f.cwd},undefined,{workspaceId:'w'}):
      f.m.resumeAgentFromPersistence({provider:'codex',sessionId:'saved'},{cwd:f.cwd},undefined,{workspaceId:'w'});
    await vi.waitFor(()=>expect(sessionLive).toBe(true));expect(f.m.listAgents()).toEqual([]);
    expect(await auto(f)).toBe('archived');expect(existsSync(f.cwd)).toBe(false);expect(sessionLive).toBe(true);
    held.release();const a=await pending;expect(f.m.getAgent(a.id)?.lifecycle).toBe('idle');
    expect(existsSync(a.cwd)).toBe(false);await f.m.closeAgent(a.id);
  }finally{held.release();await pending?.catch(()=>{});rmSync(f.base,{recursive:true,force:true})}
});

test.each([false,true])('manual archive final check control foreign=%s',async(foreign)=>{
  const f=await fixture();try{
    const a=await f.m.createAgent({provider:'codex',cwd:f.cwd},undefined,{workspaceId:foreign?'other':'w'});
    const result=await archiveByScope(f.deps,{scope:{kind:'workspace',workspaceId:'w'},requestId:'manual'});
    expect(result.archivedWorkspaceIds).toEqual(['w']);expect(result.removedDirectory).toBe(!foreign);
    expect(existsSync(f.cwd)).toBe(foreign);
    if(foreign){expect(result.deferredByAgentIds).toEqual([a.id]);await f.m.closeAgent(a.id);}
  }finally{rmSync(f.base,{recursive:true,force:true})}
});

test('final deferral after record archive loses retry; symlink cwd changes filesystem identity',async()=>{
  const f=await fixture();let sub:any;try{
    const outside=join(f.base,'outside');mkdirSync(outside);const alias=join(f.base,'alias');symlinkSync(outside,alias);
    const a=await f.m.createAgent({provider:'codex',cwd:alias},undefined,{workspaceId:'other'});
    const recorded=f.deps.archiveWorkspaceRecord;let marker:string|null=null;let attempts=0;
    f.deps.archiveWorkspaceRecord=async(id:string,ctx:any)=>{marker=ctx.autoArchivedChangeRequestUrl;await recorded(id)};
    f.deps.killTerminalsForWorkspace=async()=>{unlinkSync(alias);symlinkSync(f.cwd,alias)};
    let emit:any;const read=vi.fn(async()=>({...snapshot(),cwd:f.cwd}));const outcomes:string[]=[];
    const options:any={...f.deps,logger,daemonConfigStore:{get:()=>({autoArchiveAfterMerge:true})},
      getAutoArchivedChangeRequestUrl:async()=>marker,
      workspaceGitService:{getSnapshot:read,onSnapshotUpdated:(cb:any)=>{emit=cb;return {unsubscribe(){}}}}};
    sub=setupAutoArchiveOnMerge(options,{resolvePath:resolve,archiveIfSafe:async(input:any)=>{
      attempts++;const result=await archiveIfSafe({...input,deps:{archiveByScope,
        isPaseoOwnedWorktreeCwd:async()=>({allowed:true,worktreePath:f.cwd}),killTerminalsForWorkspace:f.deps.killTerminalsForWorkspace}});
      outcomes.push(result);return result;
    }});
    emit({...snapshot(false),cwd:f.cwd});emit({...snapshot(),cwd:f.cwd});
    await vi.waitFor(()=>expect(outcomes).toEqual(['deferred']));
    expect(await f.deps.listActiveWorkspaces()).toEqual([]);expect(marker).toBe(snapshot().forge.pullRequest.url);
    expect(existsSync(f.cwd)).toBe(true);await f.m.closeAgent(a.id);
    await vi.waitFor(()=>expect(read.mock.calls.length).toBeGreaterThanOrEqual(2));await tick();await tick();
    expect(attempts).toBe(1);expect(existsSync(f.cwd)).toBe(true);
    const direct=await archiveIfSafe({workspaceId:'w',snapshot:{...snapshot(),cwd:f.cwd},options,log:logger,
      deps:{archiveByScope,isPaseoOwnedWorktreeCwd:async()=>({allowed:true,worktreePath:f.cwd}),killTerminalsForWorkspace:async()=>{}}});
    expect(direct).toBe('skipped');
  }finally{sub?.unsubscribe();rmSync(f.base,{recursive:true,force:true})}
});

test('foreign idle deferral logs identity on each attempt and clears after close',async()=>{
  const f=await fixture();try{
    const a=await f.m.createAgent({provider:'codex',cwd:f.cwd},undefined,{workspaceId:'other'});
    const messages:any[]=[];const log:any={info:(...args:any[])=>messages.push(args),warn:()=>{}};
    const attempt=()=>archiveIfSafe({workspaceId:'w',snapshot:{...snapshot(),cwd:f.cwd},log,
      options:{...f.deps,getAutoArchivedChangeRequestUrl:async()=>null},
      deps:{archiveByScope,isPaseoOwnedWorktreeCwd:async()=>({allowed:true,worktreePath:f.cwd}),killTerminalsForWorkspace:async()=>{}}});
    for(let i=0;i<6;i++)expect(await attempt()).toBe('deferred');
    expect(messages).toHaveLength(6);expect(messages.every(([fields])=>fields.agentIds.includes(a.id))).toBe(true);
    expect(await f.deps.listActiveWorkspaces()).toHaveLength(1);expect(existsSync(f.cwd)).toBe(true);
    await f.m.closeAgent(a.id);expect(await attempt()).toBe('archived');expect(existsSync(f.cwd)).toBe(false);
  }finally{rmSync(f.base,{recursive:true,force:true})}
});
