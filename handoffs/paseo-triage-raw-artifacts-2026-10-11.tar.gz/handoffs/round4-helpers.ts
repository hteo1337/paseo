import { test, expect, vi } from 'vitest';
import pino from 'pino';
import { mkdtempSync, mkdirSync, symlinkSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { AgentManager } from '../packages/server/src/server/agent/agent-manager.js';
import { archiveIfSafe } from '../packages/server/src/server/auto-archive-on-merge/archive-if-safe.js';
import { setupAutoArchiveOnMerge } from '../packages/server/src/server/auto-archive-on-merge/index.js';
import { archiveByScope } from '../packages/server/src/server/workspace-archive-service.js';
const logger = pino({level:'silent'});
const tick = () => new Promise<void>(r => setImmediate(r));
const gate = () => { let release!: () => void; const promise = new Promise<void>(r => release=r); return {promise,release}; };
function client() {
  const sessions: any[]=[];
  const c: any = {
    provider:'codex', capabilities:{supportsStreaming:false, supportsSessionPersistence:false, supportsSessionListing:true},
    isAvailable:async()=>true, fetchCatalog:async()=>({models:[],modes:[]}),
    createSession:async(config:any)=> {
      const subscribers=new Set<any>();
      const s:any={provider:'codex',id:crypto.randomUUID(),capabilities:c.capabilities,
        subscribe:(cb:any)=>{subscribers.add(cb);return ()=>subscribers.delete(cb)},
        push:(event:any)=>{for(const cb of subscribers)cb({provider:'codex',...event})},
        describePersistence:()=>({provider:'codex',sessionId:s.id}),
        getRuntimeInfo:async()=>({provider:'codex',sessionId:s.id,model:null,modeId:null}),
        getPendingPermissions:()=>[],getAvailableModes:async()=>[],getCurrentMode:async()=>null,
        close:async()=>{},interrupt:async()=>{},streamHistory:async function*(){},
        startTurn:async()=>({turnId:'foreground'})};
      sessions.push(s);return s;
    },
  };
  c.resumeSession=async(_:any,config:any)=>c.createSession(config);
  return {c,sessions};
}
function snapshot(merged=true):any {return {cwd:'/review/tree',git:{isDirty:false,aheadOfOrigin:0},forge:{pullRequest:{url:'https://example.test/pr/1',state:merged?'merged':'open',isMerged:merged}}};}
function journey(archive:any) {
  let emitSnapshot:any, emitAgent:any;
  const opts:any={logger,daemonConfigStore:{get:()=>({autoArchiveAfterMerge:true})},
    agentManager:{subscribe:(cb:any)=>{emitAgent=cb;return ()=>{}}},
    workspaceGitService:{onSnapshotUpdated:(cb:any)=>{emitSnapshot=cb;return {unsubscribe(){}}},getSnapshot:vi.fn(async()=>snapshot())},
    listActiveWorkspaces:async()=>[{workspaceId:'w',cwd:'/review/tree'}]};
  const subscription=setupAutoArchiveOnMerge(opts,{archiveIfSafe:archive,resolvePath:resolve});
  emitSnapshot(snapshot(false));emitSnapshot(snapshot());
  return {opts,subscription,emitAgent};
}

export { client, journey, snapshot, gate, tick, logger };
