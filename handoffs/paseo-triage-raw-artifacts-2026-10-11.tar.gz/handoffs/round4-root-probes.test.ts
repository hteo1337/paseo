import { test, expect, vi } from 'vitest';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, existsSync, rmSync } from 'node:fs';
import { resolve, join, win32, posix } from 'node:path';
import { client, journey, snapshot, gate, tick, logger } from './round4-helpers.js';
import { AgentManager } from '../packages/server/src/server/agent/agent-manager.js';
import { archiveByScope } from '../packages/server/src/server/workspace-archive-service.js';
import { archiveIfSafe } from '../packages/server/src/server/auto-archive-on-merge/archive-if-safe.js';
import { createWorktree } from '../packages/server/src/utils/worktree.js';
import { isPathInsideRoot } from '../packages/server/src/utils/path.js';

async function fixture() {
  const base=mkdtempSync(resolve('handoffs/round4-fixture-'));
  const repo=join(base,'repo');mkdirSync(repo);
  const git=(args:string[])=>execFileSync('git',args,{cwd:repo,stdio:'pipe'});
  git(['init','-b','main']);
  git(['-c','user.name=Probe','-c','user.email=probe@example.test','-c','commit.gpgsign=false','commit','--allow-empty','-m','fixture']);
  const home=join(base,'home');
  const tree=await createWorktree({cwd:repo,worktreeSlug:'probe',source:{kind:'branch-off',baseBranch:'main',branchName:'probe'},runSetup:false,paseoHome:home});
  const cwd=tree.worktreePath;
  const {c,sessions}=client();const m=new AgentManager({clients:{codex:c},logger});
  let archived=false;
  const deps:any={paseoHome:home,agentManager:m,agentStorage:{listByWorkspace:async()=>[]},
    listActiveWorkspaces:async()=>archived?[]:[{workspaceId:'w',cwd,kind:'worktree',isPaseoOwnedWorktree:true,worktreeRoot:cwd,mainRepoRoot:repo}],
    archiveWorkspaceRecord:async()=>{archived=true},markWorkspaceArchiving:()=>{},clearWorkspaceArchiving:()=>{},
    emitWorkspaceUpdatesForWorkspaceIds:async()=>{},killTerminalsForWorkspace:async()=>{},
    workspaceGitService:{getSnapshot:async()=>({})},github:{invalidate:()=>{}},sessionLogger:logger};
  return {base,cwd,home,c,sessions,m,deps};
}

test.each(['early','late-existing','late-create','late-resume'])(
  'P1 real deletion vs autonomous provider start: %s',async(mode)=>{
    const f=await fixture();try {
      let a:any;let admissionBlocked=false;let checks=0;
      if(mode==='early'||mode==='late-existing'){
        const child=f.cwd;
        a=await f.m.createAgent({provider:'codex',cwd:child},undefined,{workspaceId:'other'});
      }
      const start=async()=>{
        if(mode==='late-create')a=await f.m.createAgent({provider:'codex',cwd:f.cwd},undefined,{workspaceId:'w'});
        if(mode==='late-resume')a=await f.m.resumeAgentFromPersistence({provider:'codex',sessionId:'saved'},{cwd:f.cwd},undefined,{workspaceId:'w'});
        expect(()=>f.m.streamAgent(a.id,'control')).toThrow('being archived');admissionBlocked=true;
        f.sessions[0].push({type:'turn_started',turnId:'autonomous'});
        expect(f.m.hasInFlightRun(a.id)).toBe(true);await tick();
      };
      if(mode==='early')f.deps.emitWorkspaceUpdatesForWorkspaceIds=async()=>{if(!admissionBlocked)await start()};
      else f.deps.killTerminalsForWorkspace=async()=>{expect(checks).toBe(2);await start()};
      const result=await archiveByScope(f.deps,{scope:{kind:'workspace',workspaceId:'w'},requestId:'round4',
        abortIf:()=>{checks++;return f.m.listAgents().filter(a=>f.m.hasInFlightRun(a.id)).map(a=>a.id)},
        holdNewRuns:()=>f.m.holdNewRunsForArchive('w',f.cwd)});
      expect(admissionBlocked).toBe(true);expect(checks).toBe(2);
      expect(f.m.hasInFlightRun(a.id)).toBe(true);expect(f.m.getAgent(a.id)?.lifecycle).toBe('running');
      expect(existsSync(f.cwd)).toBe(mode==='early');
      expect(result.removedDirectory).toBe(mode!=='early');
    }finally{rmSync(f.base,{recursive:true,force:true})}
  });

test.each(['early','late'])('P3 real unsubscribe at %s await',async(mode)=>{
  const f=await fixture();const held=gate();let entered=false;let archivedAfterUnsubscribe=false;let unsubscribed=false;
  try {
    const mark=f.deps.archiveWorkspaceRecord;
    f.deps.archiveWorkspaceRecord=async()=>{archivedAfterUnsubscribe=unsubscribed;await mark()};
    const pause=async()=>{entered=true;await held.promise};
    if(mode==='early')f.deps.agentStorage.listByWorkspace=async()=>{await pause();return []};
    else f.deps.killTerminalsForWorkspace=pause;
    const outcomes:string[]=[];
    const j=journey(async(input:any)=>{
      const outcome=await archiveIfSafe({...input,snapshot:{...input.snapshot,cwd:f.cwd},
        options:{...input.options,...f.deps,getAutoArchivedChangeRequestUrl:async()=>null},
        deps:{isPaseoOwnedWorktreeCwd:async()=>({allowed:true,worktreePath:f.cwd}),archiveByScope,
          killTerminalsForWorkspace:f.deps.killTerminalsForWorkspace}});
      outcomes.push(outcome);return outcome;
    });
    await vi.waitFor(()=>expect(entered).toBe(true));expect(existsSync(f.cwd)).toBe(true);
    j.subscription.unsubscribe();unsubscribed=true;held.release();
    await vi.waitFor(()=>expect(outcomes.length).toBe(1));
    expect(archivedAfterUnsubscribe).toBe(mode==='late');
    expect(existsSync(f.cwd)).toBe(mode==='early');
    expect(outcomes).toEqual([mode==='early'?'skipped':'archived']);
  }finally{held.release();rmSync(f.base,{recursive:true,force:true})}
});

test.each(['reject','close'])('counter cleanup after %s while tail pending',async(mode)=>{
  const {c,sessions}=client();const m:any=new AgentManager({clients:{codex:c},logger});
  const a=await m.createAgent({provider:'codex',cwd:process.cwd()},undefined,{workspaceId:'w'});
  const held=gate();const original=m.dispatchSessionEvent.bind(m);
  m.dispatchSessionEvent=async(...args:any[])=>{await held.promise;if(mode==='reject')throw Error('injected dispatch failure');return original(...args)};
  sessions[0].push({type:'turn_started',turnId:'one'});sessions[0].push({type:'turn_started',turnId:'two'});
  expect(m.pendingProviderTurnStarts.get(a.id)).toBe(2);expect(m.hasInFlightRun(a.id)).toBe(true);
  const closed=mode==='close'?m.closeAgent(a.id):Promise.resolve();held.release();await closed;await tick();await tick();
  expect(m.pendingProviderTurnStarts.has(a.id)).toBe(false);expect(m.hasInFlightRun(a.id)).toBe(false);
  expect(m.sessionEventTails.has(a.id)).toBe(false);
});

test('containment: dot prefixes accepted, traversal and outside roots rejected across path dialects',()=>{
  const roots=[{root:'/root/tree',p:posix},{root:'C:\\root\\tree',p:win32},{root:'\\\\host\\share\\tree',p:win32}];
  for(const {root,p} of roots){
    for(const name of ['ordinary','..cache','...','..cache/child'])expect(isPathInsideRoot(root,p.join(root,name))).toBe(true);
    for(const suffix of ['..','../x','..\\x']){
      if(p===posix&&suffix.includes('\\'))continue;
      expect(isPathInsideRoot(root,p.join(root,suffix))).toBe(false);
    }
    expect(isPathInsideRoot(root,root+'-sibling')).toBe(false);
  }
  expect(isPathInsideRoot('C:\\root\\tree','D:\\root\\tree\\..cache')).toBe(false);
  expect(isPathInsideRoot('C:/root/tree','C:/root/tree/../x')).toBe(false);
  expect(isPathInsideRoot('C:/root/tree','C:/root/tree/..cache')).toBe(true);
});
