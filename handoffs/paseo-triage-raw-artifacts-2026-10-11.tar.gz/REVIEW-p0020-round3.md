# Patch 0020 — adversarial review, round 3

Reviewed `60429185f..c9e00be2a`, HEAD `c9e00be2a14824ed11bba79bf47cd874bdf05c92`. Four findings; source unchanged.

## Findings, ordered by severity

### P1 — Provider-originated turns bypass the archive admission hold

**Location:** `packages/server/src/server/agent/agent-manager.ts:2484`, `:4573`; registration paths at `:1232`, `:1301`, `:3532`.

The new check covers `streamAgent` only. An idle provider can emit `turn_started` after the last busy check and while the hold is active; `onStreamTurnStarted` tracks it and sets lifecycle to running without checking the hold. Creation and persisted resume also register sessions under an active hold, including a synchronous autonomous replay on subscription.

**Deterministic probes:** `handoffs/round3-probes.test.ts:45`, `:55`, `:118`. With the hold active, the control `streamAgent` throws, but an autonomous event changes `hasInFlightRun` from false to true. The integrated probe uses real `archiveByScope` and AgentManager: inject that event during the first workspace-update await for a cwd-matching agent with another workspaceId; record teardown observes the agent still running and returns `archivedWorkspaceIds: ['w']`. No worktree was actually deleted by this probe.

### P2 — A `..`-prefixed descendant escapes the path hold

**Location:** `packages/server/src/server/agent/agent-manager.ts:2472`, calling `packages/server/src/utils/path.ts:119`.

`isPathInsideRoot` rejects every relative path starting with `..`, including a legitimate descendant named `..cache`. For an agent with another workspaceId but cwd under the deleted root, the earlier busy scan recognizes this location while the new hold does not, permitting a new foreground run during archive.

**Deterministic probe:** `handoffs/round3-probes.test.ts:137` creates real sibling directories `ordinary` and `..cache` beneath the held root. `streamAgent` rejects the ordinary descendant, accepts `..cache`, and `hasInFlightRun` becomes true. The helper predates this diff; its new use as the run-admission boundary exposes this hole.

### P2 — A transient snapshot failure after retry exhaustion strands the deferral

**Location:** `packages/server/src/server/auto-archive-on-merge/index.ts:54`, `:104`, `:155`.

After five timer retries, the terminal event still triggers a fresh attempt, but if that snapshot read rejects, the exhausted attempt counter remains unchanged. The deferral stays in memory with no timer or continuation; a quiet workspace will not archive unless another independent event arrives.

**Deterministic probe:** `handoffs/round3-probes.test.ts:80` uses fake time to observe six calls (initial plus five retries), stops the blocker with an error event, and rejects exactly that snapshot read. After another simulated hour: zero archives and zero timers; injecting an additional idle event archives successfully. Controls at `:71` prove idle, error, and closed each retry successfully after exhaustion when the read succeeds.

### P3 — Unsubscribe cannot cancel an attempt already inside archiveIfSafe

**Location:** `packages/server/src/server/auto-archive-on-merge/index.ts:132`, `:181`; `packages/server/src/server/auto-archive-on-merge/archive-if-safe.ts:76`, `:100`.

Disposal is checked before entering `archiveIfSafe`, but no cancellation predicate is passed into it or its final `abortIf`. Unsubscribe during its ownership lookup therefore returns before a later continuation calls `archiveByScope`.

**Deterministic probe:** `handoffs/round3-probes.test.ts:62` invokes real `archiveIfSafe`, pauses its injected ownership lookup, verifies zero archive calls, unsubscribes, then releases the lookup. The archive dependency is called once afterwards; destructive operations are replaced by a recording adapter.

## Claim coverage

1. Findings above cover autonomous live events, create/resume replay, and cwd containment. **Nothing found** in the synchronous `abortIf` → `holdNewRuns` boundary or `streamAgent` admission → pending-run registration: there is no await in either interval, and pending runs count as busy before lifecycle becomes running. Traced MCP `create_agent` through `paseo-tools.ts:1464` → `create-agent/create.ts:184` and its initial prompt dispatcher; scheduled prompts through `schedule/service.ts:858` → `startAgentRun`; ordinary prompts reach `streamAgent`, while steering requires an existing tracked turn and replacements return through `streamAgent`.
2. Retry-exhaustion/read-failure finding above. **Nothing found** for successful idle/error/closed terminal reads after exhaustion or a stop event overlapping a deferred flight; controls at probe lines 71 and 131 passed.
3. In-flight cancellation finding above. **Nothing found** for queued idle replays, deferred timers, or attempts paused before the fresh snapshot returns: existing requested suites cover those guards. Queued immediates are guarded against disposal rather than explicitly cleared.
4. **Nothing found** for leaked holds or blocking unrelated sibling workspaces. Six injected failures (setup stop, mark, first emit, archive record, clear, final emit) each acquired/released the hold exactly once; overlapping holds release independently, symlink and on-disk case aliases remain held, and a sibling-prefix directory stays usable. The containment false negative is reported separately above; actual worktree-command failure injection was not added, though the enclosing release finally was inspected.

## Verification and reproduction

- Existing node_modules; `require.resolve('vitest')` returned this worktree's `node_modules/vitest/index.cjs`.
- Initial requested run: six suite import failures, no tests executed, because built workspace declarations were absent (`handoffs/round3-suite.log`).
- `npm run build:server`: exit 0 (`handoffs/round3-build.log`); no tracked source diff after generation/build.
- Requested command from `packages/server`: **6 files, 253 tests passed**, 17.15s (`handoffs/round3-suite-built.log`). This is local test evidence, not CI or a solo merge gate.
- From the worktree root: `npx vitest run --config packages/server/vitest.config.ts handoffs/round3-probes.test.ts`: **19 probes passed**, 1.08s (`handoffs/round3-probes.log`). Finding probes assert the observed defective behavior; green means the reproduction succeeded, not that the claim holds.
- Probes use real reviewed implementations with deterministic provider/dependency adapters and real filesystem aliases; no live provider or production daemon was invoked. These are current-head counterexamples, not claims that every underlying defect originated in this commit.
